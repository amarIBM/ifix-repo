#!/bin/sh
####################################################################################
#
# Licensed Materials - Property of IBM
#
# (c) Copyright IBM Corp. 2013,2016 All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#
####################################################################################
# For the version of this script, see MQSIF_SCRIPTVERSION below.
####################################################################################
#
# NAME:        mqsifixinst.sh
#
# Description: This script is used to install or uninstall an IBM Integration Bus
#              or IBM App Connect Enterprise test or interim fix that is provided
#              by IBM Support into a given IBM Integration Bus or IBM App Connect
#              Enterprise installation.
#
# WARNING:     This script is provided to install the fix that you have
#              received from IBM.  The script might be changed in the future;
#              therefore, please do not store it and reuse for a later fix.
#              Please use the latest script that IBM includes with the later fix.
#
# Usage:
#              mqsifixinst.sh {Installation_Dir} {Action} [FixName] [verbose]
#
# Parameters:
#
#   Installation_Dir
#     Installation_Dir is a required parameter that specifies the IBM Integration Bus
#     or IBM App Connect Enterprise installation where you want to install the fix.
#
#   Action
#     Action is a required parameter that specifies the action that you want to
#     complete. Set this parameter to one of the following values:
#
#     'testinstall'   - Log to the console the actions that are completed
#                       while installing the fix, but make no changes.
#     'install'       - Install the interim or test fix.
#     'testuninstall' - Log to the console the actions that are completed
#                       while uninstalling the fix, but make no changes.
#     'uninstall'     - Uninstall the interim or test fix.
#     'uninstall_all' - Uninstall all interim and test fixes.
#
#   [FixName]
#     FixName is an optional parameter for the (test)install and (test)uninstall
#     actions that specifies the name of the test or interim fix that you want
#     to install or uninstall.
#     If you do not specify a FixName, the script attempts to detect the
#     name of the test or interim fix to install. If mqsifixinst cannot
#     determine a unique fix name, a list of available fixes is logged
#     to the console.
#
#   [Verbose]
#     Verbose is an optional parameter that enables verbose logging to the
#     console.
#
# Examples:
#   ./mqsifixinst.sh /opt/IBM/mqsi/11.0.0.0 testinstall 11.0.0.0-ACE-AIXPPC64-TFP12345
#   ./mqsifixinst.sh /opt/IBM/mqsi/11.0.0.0 install 11.0.0.0-ACE-AIXPPC64-TFP12345
#   ./mqsifixinst.sh /opt/IBM/mqsi/11.0.0.0 install
#   ./mqsifixinst.sh /opt/IBM/mqsi/11.0.0.0 testuninstall 11.0.0.0-ACE-AIXPPC64-TFP12345
#   ./mqsifixinst.sh /opt/IBM/mqsi/11.0.0.0 uninstall 11.0.0.0-ACE-AIXPPC64-TFP12345
#   ./mqsifixinst.sh /opt/IBM/mqsi/11.0.0.0 uninstall_all
#
####################################################################################

# If you want the program to prompt before the running of all 'rm' commands,
#  uncomment this line.
#alias rm='rm -i'

####################################################################################
# Set the shell appropriately for the platform.
####################################################################################
CURRENT_OS=`uname`
CURRENT_IFS=$IFS
IFS_NEWLINE_SPLIT='
';

if [ "$MQSIFIXFORK" != "Y" ] ; then

  echo MAIN process $$ - Program/args: $0 $*

  MQSIFIXFORK=Y
  export MQSIFIXFORK

  # If we are on Linux, run sh
  if [ "$CURRENT_OS" = "Linux" ] ; then
    exec /bin/sh "$0" "$@"
  fi
  # else run ksh
  exec /bin/ksh "$0" "$@"

  # We will never get here
  echo ERROR
  exit

fi

echo ""

AllDirFiles=''
AwkOutput='undef'
ActionAsked='undef'
avoid_mqsipatch_check=0
avoid_root_check=0
avoid_ps_check=0
avoid_toolkit_init=0
Available_FixNames=''
APAR='undef'
BaseFilename='undef'
BackupDirName='undef'
BackupRootDirName='undef'
ConflictFoundM=0
ConflictList=''
CurVersion='undef'
cmd='undef'
CmdLineFixname='undef'
dryrun=1
Date='undef'
DirRemoveFileList=''
DirRemoveSymlinkList=''
DirList=''
DotXFixName=0
DoToolkitInit=0
ExistingFileList=''
ExistingOpaqueDirList=''
firstinstall=0
Filename='undef'
FileList=''
FixName=''
Find_Fixname=0
GrepOutput='undef'
InstallDir='/var/mqm/undef'
InputArgs='undef'
InstalledFixList=''
MqsifixinstDatFile='undef'
MqsifixinstMdFile='undef'
MqsiprofileLoc='/bin/mqsiprofile'
MqsiTenFix=0
NewFileList=''
NewDirList=''
NewOpaqueDirList=''
NextBaseDirName=''
OriginalDir='undef'
OpaqueDirList=''
PatchVersion='undef'
PermissionFileList=''
PLATFORM='undef'
PrevBaseDirName=''
ReadmeDir='undef'
ReadmeFile='undef'
SymLinkFileList=''
rc=0
ThisScript='undef'
ThisScriptName='mqsifixinst.sh'
UDirList=''
UDirNewFiles=''
UExistingFileList=''
UExistingOpaqueDirList=''
UFileList=''
UNewFileList=''
UOpaqueDirList=''
URemoveDirList=''
URemoveOpaqueDirList=''
URemoveFileList=''
USymLinkFileList=''
USymLinkExistingList=''
USymLinkRemoveList=''
UninstallAllCount=0
UninstallBackupDirName='undef'
UninstallRootBackupDir='undef'
uninstall=0
uninstall_all=0
Verbose_Mqsi=0
Enable_Logfile=0

MQSIF_SCRIPTVERSION=144


####################################################################################
# FUNCTION mqsilog :
# Always logs a message to the mqsifixinst.log file;
# logs a message to the console in verbose mode.
####################################################################################
mqsilog()
{
  # Need to reset IFS here to stop the arguments logging on separate lines
  LOCAL_IFS=$IFS
  IFS=$CURRENT_IFS
  Ltime=$(date +\%Y/\%m/\%d\ \%H:\%M:\%S)
  if [ $Verbose_Mqsi -eq 1 ] ; then
    /bin/echo "$*"
  fi
  if [ $dryrun -eq 0 ] && [ $Enable_Logfile -eq 1 ] ; then
    /bin/echo $Ltime "$*" >> "$InstallDir/mqsifixinst.log"
  fi
  IFS=$LOCAL_IFS
}


####################################################################################
# FUNCTION mqsiecho : Always logs a message to the console.
####################################################################################
mqsiecho()
{
  /bin/echo "$*"
}


####################################################################################
# FUNCTION mqsiechonlog : Logs a message to the console and mqsifixinst.log file.
####################################################################################
mqsiechonlog()
{
  # If this is a failure message then add an automatic Result Summary line.
  loglinetype=$*
  loglinetype=`echo $loglinetype | awk -F':' '{print $1}'`
  if [ "$loglinetype" = "FAILURE" ] ; then
    /bin/echo ""
    /bin/echo "-------------------------------------------------------------------------------"
    /bin/echo "INFO:    Result Summary"
    /bin/echo "-------------------------------------------------------------------------------"
  fi

  Ltime=$(date +\%Y/\%m/\%d\ \%H:\%M:\%S)
  /bin/echo "$*"
  if [ $dryrun -eq 0 ] && [ $Enable_Logfile -eq 1 ] ; then
    /bin/echo $Ltime "$*" >> "$InstallDir/mqsifixinst.log"
  fi
}


####################################################################################
# FUNCTION runcmd : Executes the named command, when not in dry-run mode.
####################################################################################
runcmd()
{
  mqsilog "CMD:    " $*
  if [ $dryrun -eq 0 ] ; then
    "$@"
    return $?
  else
    return 0
  fi
}


####################################################################################
# FUNCTION mqsicopy :
# Copies the supplied file to the destination, taking symbolic links into account.
####################################################################################
mqsicopy()
{

  SourceFileMqsi=$1
  DestinationFileMqsi=$2

  if [ -h "$SourceFileMqsi" ] && [ -h "$DestinationFileMqsi" ] ; then

    SourceFileActual=$(ls -l "$SourceFileMqsi" | awk '{print $NF}')
    DestFileActual=$(ls -l "$DestinationFileMqsi" | awk '{print $NF}')

    if [ "$SourceFileActual" = "$DestFileActual" ] ; then
      mqsilog "INFO:    No copy required for symbolic link $DestinationFileMqsi because both "
      mqsilog "         the original and new symolic links point to the same target."
      return 0
    fi

  elif [ -h "$SourceFileMqsi" ] || [ -h "$DestinationFileMqsi" ] ; then

     if [ -h "$DestinationFileMqsi" ] || [ -f "$DestinationFileMqsi" ] ; then

       mqsilog "INFO:    Removing the original file $DestinationFileMqsi before copying in the new one."
       runcmd rm "$DestinationFileMqsi"

       if [ ! -h "$SourceFileMqsi" ] ; then
         mqsilog "WARNING: A file $SourceFileMqsi is replacing a symbolic link $DestinationFileMqsi."
         if [ -z "$PermissionFileList" ] ; then
           PermissionFileList="$DestinationFileMqsi"
         else
           PermissionFileList="$PermissionFileList$IFS_NEWLINE_SPLIT$DestinationFileMqsi"
         fi
       else
         mqsilog "WARNING: A symbolic link $SourceFileMqsi is replacing a file $DestinationFileMqsi."
       fi
     fi

  fi

  if [ -h "$SourceFileMqsi" ] ; then
    if [ "$(uname)" = "HP-UX" ] ; then
      # We need to remember the current umask so we can restore it after we override it to copy a symlink.
      # HP uses the umask to set permissions on symlinks and does not just set 777 like other OS's.
      prevUmask=$(umask)
      runcmd umask 000
      runcmd cp -r -P -p "$SourceFileMqsi" "$DestinationFileMqsi"
      runcmd umask $prevUmask
    elif [ "$(uname)" = "SunOS" ] ; then
      # Solaris is unable to copy symlinks which do not point at anything so detect and create instead
      SourceFileActual=$(ls -l "$SourceFileMqsi" | awk '{print $NF}')
      FirstChar="echo $SourceFileActual | cut -c1,1"
      if [ "$FirstChar" = "/" ] ; then
        # Absoloute path
        if [ -h "$SourceFileActual" ] || [ -f "$SourceFileActual" ] ; then
          runcmd cp -r -P "$SourceFileMqsi" "$DestinationFileMqsi"
        else
          runcmd ln -s "$SourceFileActual" "$DestinationFileMqsi"
        fi
      else
        SourceDir=$(dirname "$SourceFileMqsi")
        if [ -h "$SourceDir/$SourceFileActual" ] || [ -f "$SourceDir/$SourceFileActual" ] ; then
          runcmd cp -r -P "$SourceFileMqsi" "$DestinationFileMqsi"
        else
          runcmd ln -s "$SourceFileActual" "$DestinationFileMqsi"
        fi
      fi
    else
      runcmd cp -r -P "$SourceFileMqsi" "$DestinationFileMqsi"
    fi
   else
    runcmd cp "$SourceFileMqsi" "$DestinationFileMqsi"
  fi

  return $?

}


####################################################################################
# FUNCTION usage : Displays the usage instructions.
####################################################################################
usage()
{
mqsiecho "                                                                     "
mqsiecho "USAGE:                                                               "
mqsiecho "       mqsifixinst.sh {Installation_Dir} {Action} [FixName] [verbose]"
mqsiecho "                                                                     "
mqsiecho "Parameters:                                                          "
mqsiecho "                                                                     "
mqsiecho "  Installation_Dir                                                   "
mqsiecho "    Installation_Dir is a required parameter that specifies          "
mqsiecho "    the IBM Integration Bus or IBM App Connect Enterprise            "
mqsiecho "    installation where you want to install the fix.                  "
mqsiecho "                                                                     "
mqsiecho "  Action                                                             "
mqsiecho "    Action is a required parameter that specifies the action that you"
mqsiecho "    want to complete.                                                "
mqsiecho "    Set this parameter to one of the following values:               "
mqsiecho "                                                                     "
mqsiecho "    'testinstall'   - Log to the console the actions that are        "
mqsiecho "                      completed while installing the fix,            "
mqsiecho "                      but make no changes.                           "
mqsiecho "    'install'       - Install the interim or test fix.               "
mqsiecho "    'testuninstall' - Log to the console the actions that are        "
mqsiecho "                      completed while uninstalling the fix,          "
mqsiecho "                      but make no changes.                           "
mqsiecho "    'uninstall'     - Uninstall the interim or test fix.             "
mqsiecho "    'uninstall_all' - Uninstall all interim and test fixes.          "
mqsiecho "                                                                     "
mqsiecho "  [FixName]                                                          "
mqsiecho "    FixName is an optional parameter for the (test)install           "
mqsiecho "    and (test)uninstall actions that specifies the name              "
mqsiecho "    of the test or interim fix that you want to install or uninstall."
mqsiecho "    If you do not specify a FixName, the script attempts to detect   "
mqsiecho "    the name of the test or interim fix to install. If mqsifixinst   "
mqsiecho "    cannot determine a unique fix name, a list of available fixes    "
mqsiecho "    is logged to the console.                                        "
mqsiecho "                                                                     "
mqsiecho "  [Verbose]                                                          "
mqsiecho "    Verbose is an optional parameter that enables verbose logging    "
mqsiecho "    to the console.                                                  "
mqsiecho "                                                                     "
mqsiecho "Examples:                                                            "
mqsiecho "  ./mqsifixinst.sh /opt/IBM/mqsi/11.0.0.0 testinstall 11.0.0.0-ACE-AIXPPC64-TFP12345"
mqsiecho "  ./mqsifixinst.sh /opt/IBM/mqsi/11.0.0.0 install 11.0.0.0-ACE-AIXPPC64-TFP12345"
mqsiecho "  ./mqsifixinst.sh /opt/IBM/mqsi/11.0.0.0 install                     "
mqsiecho "  ./mqsifixinst.sh /opt/IBM/mqsi/11.0.0.0 testuninstall 11.0.0.0-ACE-AIXPPC64-TFP12345"
mqsiecho "  ./mqsifixinst.sh /opt/IBM/mqsi/11.0.0.0 uninstall 11.0.0.0-ACE-AIXPPC64-TFP12345"
mqsiecho "  ./mqsifixinst.sh /opt/IBM/mqsi/11.0.0.0 uninstall_all               "
mqsiecho "                                                                     "
}


####################################################################################
# FUNCTION mqsifixinst_to_installdir :
# Check if the installation directory contains a later or equal version of the script.
# If not, copy this one to the installation directory.
####################################################################################
mqsifixinst_to_installdir()
{

  mqsilog "INFO:    Copy this script into the installation root directory but do not overwrite if a later version is already in place."

  if [ -f "$InstallDir/$(basename "$ThisScript")" ] ; then
    Cmd="grep MQSIF_SCRIPTVERSION= $InstallDir/$(basename "$ThisScript") | grep -v grep | cut -d= -f2"
    mqsilog "CMD:     $Cmd"
    MQSIF_INSTALLEDVERSION=$(grep "MQSIF_SCRIPTVERSION=" "$InstallDir/$(basename "$ThisScript")" | grep -v grep | cut -d= -f2)
    if [ $MQSIF_SCRIPTVERSION -gt $MQSIF_INSTALLEDVERSION ] ;then
      runcmd cp "$ThisScript" "$InstallDir/$(basename "$ThisScript")"
    fi
  else
    runcmd cp "$ThisScript" "$InstallDir/$(basename "$ThisScript")"
  fi

}


####################################################################################
# FUNCTION mqsi_populate_install_filelist :
# Create the file list to be installed
####################################################################################
mqsi_populate_install_filelist()
{

  mqsilog "INFO:    Generating the list of Files to be Installed."

  # The MD5 file lists all the various components that are included in the fix. Each
  # line in the file corresponds to a single component and has the following format:
  #
  # <filmd>;<filename>;<size>
  #
  # The filmd field is either the MD5 hash of the new file if it is a regular file,
  # or one of "null", "directory", "opaque_dir", or "symlink" if it is not a regular file.
  #
  # A "null" file is one that is ignored and not installed, this is reserved for the readme,
  # MD5, and .dat files.
  # 
  # A "directory" represents a folder (tree) whose entire contents are being replaced. The
  # directory is scanned iteratively to preserve symlinks and warnings are given when a file
  # exists in the currently installed?tree version but not in the new tree.
  #
  # A "symlink" represents a file that is actually a symbolic link to another file. These
  # must be created and deleted correctly to ensure they still point to the correct location
  # after installation.
  #
  # An "opaque_dir" is an opaque directory that the fix installer should not try to inspect.
  # This is used by folders that are outside our control or whose structure we do not control
  # or cannot predict. It is also used for folders with very large numbers of entries which
  # might otherwise not be processable correctly. No warnings are given about differences in
  # file trees, and no special processing of symlinks is performed. This is mainly used for the
  # JDK/JRE and Node.js related folders.

  while IFS=";" read filmd filname filsize
  do
    if [ "$filmd" !=  "null" ] && [ "$filmd" !=  "directory" ] && [ "$filmd" !=  "symlink" ] && [ "$filmd" != "opaque_dir" ]; then
      if [ -z "$FileList" ] ; then
        FileList="$filname"
      else
        FileList="$FileList$IFS_NEWLINE_SPLIT$filname"
      fi
    fi

    if [ "$filmd" =  "directory" ] ; then
      if [ -z "$DirList" ] ; then
        DirList="$filname"
      else
        DirList="$DirList$IFS_NEWLINE_SPLIT$filname"
      fi
    fi

    if [ "$filmd" = "opaque_dir" ] ; then

      # HPUX and Solaris are too painful, and we should only be using opaque_dir fixes for things
      # that aren't shipped on these platfroms, e.g. node_modules
      if [ "$(uname)" = "SunOS" ] || [ "$(uname)" = "HP-UX" ] ; then
        mqsiechonlog "FAILURE: Directory '$filname' mentioned in the fix md5 file is an opaque directory, which is not supported by this script."
        mqsiechonlog "         Installation can be performed manually by following the steps in the fix readme file."
        mqsiechonlog "         Please tell IBM Support that this fix has an inappropriate directory type in it."
        exit 1
      fi

      if [ -z "$OpaqueDirList" ] ; then
        OpaqueDirList="$filname"
      else
        OpaqueDirList="$OpaqueDirList$IFS_NEWLINE_SPLIT$filname"
      fi
    fi

    if [ "$filmd" =  "symlink" ] ; then
      if [ -z "$SymLinkFileList" ] ; then
        SymLinkFileList="$filname"
      else
        SymLinkFileList="$SymLinkFileList$IFS_NEWLINE_SPLIT$filname"
      fi
    fi

    # White space in file names is not supported on Solaris or HP
    if [ "$(uname)" = "SunOS" ] || [ "$(uname)" = "HP-UX" ] ; then
    
      Ncount=$(echo  $filname | wc -w)
    
      if [ $Ncount -gt 1 ] ; then
        mqsiechonlog "FAILURE: File '$filname' mentioned in the fix md5 file contains white space, which is not supported by the script."
        mqsiechonlog "         Installation can be performed manually by following the steps given in the fix readme file."
        exit 1
      fi
    fi

  done < $MqsifixinstMdFile

  # For each standard file in the fix list, check that the file exists in the extracted folder
  # and whether it is a new file or an existing file
  IFS=$IFS_NEWLINE_SPLIT
  for Filename in $FileList
  do
    if [ ! -f "$OriginalDir/$Filename" ] && [ ! -h "$OriginalDir/$Filename" ] ; then
      mqsiechonlog "FAILURE: File $Filename mentioned in the fix md5 file does not exist in the current directory."
      mqsiechonlog "         Ensure that the fix was unpacked successfully and that no error messages were issued by tar."
      mqsiechonlog "         If an error is issued by tar that reports that \"@LongLink: typeflag 'L' not recognized\", "
      mqsiechonlog "         use a version of tar that supports long file names."

      if [ "$(uname)" = "SunOS" ] ; then
         mqsiechonlog "         On Solaris, the default version of tar does not support long file names."
         mqsiechonlog "         A version of GNU tar that supports long file names can be found in /usr/sfw/bin/gtar"
      fi

      exit 1
    fi
    if [ ! -f "$InstallDir/$Filename" ] && [ ! -h "$InstallDir/$Filename" ] ; then
      mqsilog "WARNING: File $Filename does not exist; nothing to back up."
      if [ -z "$NewFileList" ] ; then
        NewFileList="$Filename"
      else
        NewFileList="$NewFileList$IFS_NEWLINE_SPLIT$Filename"
      fi
    else
      if [ -z "$ExistingFileList" ] ; then
        ExistingFileList="$Filename"
      else
        ExistingFileList="$ExistingFileList$IFS_NEWLINE_SPLIT$Filename"
      fi
   fi
  done

  # For each normal directory in the fix list, build a list of symlinks and files
  # that are present in the install tree but not in the fix tree. These will need
  # to be removed correctly.
  for DirName in $DirList
  do

    if [ -d "$InstallDir/$DirName" ] ; then

      AllDirFiles=$(find $InstallDir/$DirName -type f -o -type l)

      for EachDirFiles in $AllDirFiles
      do
         EachDirFilesRl0=${EachDirFiles#$InstallDir}
         EachDirFilesRl=${EachDirFilesRl0#/}
         if [ ! -f "$OriginalDir/$EachDirFilesRl" ] && [ ! -h "$OriginalDir/$EachDirFilesRl" ] ; then
            if [ -h "$InstallDir/$EachDirFilesRl" ] ; then
               mqsilog "WARNING: Symbolic link $EachDirFilesRl present in the installation directory is not present in the replacement directory."
              if [ -z "$DirRemoveSymlinkList" ] ; then
                DirRemoveSymlinkList="$EachDirFilesRl"
              else
                DirRemoveSymlinkList="$DirRemoveSymlinkList$IFS_NEWLINE_SPLIT$EachDirFilesRl"
              fi
            else
              mqsilog "WARNING: File $EachDirFilesRl present in the installation directory is not present in the replacement directory."
              if [ -z "$DirRemoveFileList" ] ; then
                DirRemoveFileList="$EachDirFilesRl"
              else
                DirRemoveFileList="$DirRemoveFileList$IFS_NEWLINE_SPLIT$EachDirFilesRl"
              fi
            fi
         fi
      done

    fi

  done

  # For each opaque directory in the fix list, check it has been extracted and
  # categorise it based on whether an existing directory exists in the install tree
  for DirName in $OpaqueDirList
  do
    if [ ! -d "$OriginalDir/$DirName" ] ; then
      mqsiechonlog "FAILURE: Directory $DirName mentioned in the fix md5 file does not exist in the current directory."
      mqsiechonlog "         Ensure that the fix was unpacked successfully and that no error messages were issued by tar."
      mqsiechonlog "         If an error is issued by tar that reports that \"@LongLink: typeflag 'L' not recognized\", "
      mqsiechonlog "         use a version of tar that supports long file names."

      if [ "$(uname)" = "SunOS" ] ; then
         mqsiechonlog "         On Solaris, the default version of tar does not support long file names."
         mqsiechonlog "         A version of GNU tar that supports long file names can be found in /usr/sfw/bin/gtar"
      fi

      exit 1
    fi
    if [ ! -d "$InstallDir/$DirName" ] ; then
      mqsilog "WARNING: File $DirName does not exist; nothing to back up."
      if [ -z "$NewOpaqueDirList" ] ; then
        NewOpaqueDirList="$DirName"
      else
        NewOpaqueDirList="$NewOpaqueDirList$IFS_NEWLINE_SPLIT$DirName"
      fi
    else
      if [ -z "$ExistingOpaqueDirList" ] ; then
        ExistingOpaqueDirList="$DirName"
      else
        ExistingOpaqueDirList="$ExistingOpaqueDirList$IFS_NEWLINE_SPLIT$DirName"
      fi
   fi
  done

  # Check that ecah symlink in the fix list has been extracted correctly. Some TAR programs
  # do not handle symlinks correctly.
  for Filename in $SymLinkFileList
  do
    if [ ! -h "$OriginalDir/$Filename" ] ; then
      mqsiechonlog "FAILURE: Symbolic link $Filename mentioned in the fix md5 file does not exist in the current directory."
      mqsiechonlog "         Ensure that the fix was unpacked successfully and that no error messages were issued by tar."
      mqsiechonlog "         Please tell IBM Support about this error if the package does not contain the symbolic link."
      exit 1
    fi
  done
  IFS=$CURRENT_IFS
}


####################################################################################
# FUNCTION mqsi_check_conflict :
# Check if the fix is conflicting with already installed fixes
####################################################################################
mqsi_check_conflict()
{

      Filename=$1

      mqsilog "INFO:    Checking file $Filename"
      Basename=$(basename "$Filename")
      ConflictFoundS=0
      #####################################################################
      # Count the number of times that this file name is seen in the whole
      # of the backup root directory.  This number should be 0 or 1.
      #####################################################################
      Cmd="find $BackupRootDirName -type f -name $Basename | grep -F $Filename | wc -l"
      mqsilog "CMD:     $Cmd"
      NumberOfFilesTotal=$(find "$BackupRootDirName" -type f -name "$Basename" | grep -F "$Filename" | wc -l)

      if [ $NumberOfFilesTotal -eq 0 ] ; then
         Cmd="find $BackupRootDirName  -name \*.md5 -type f -exec grep -l -F $Filename {} \; | wc -l"
         mqsilog "CMD:     $Cmd"
         NumberOfFilesTotal=$(find "$BackupRootDirName"  -name \*.md5 -type f -exec grep -l -F "$Filename" {} \; | wc -l)
      fi

      mqsilog "INFO:    $NumberOfFilesTotal in $BackupRootDirName"

      #####################################################################
      # Count the number of times that this file name is seen in "our"
      # backup directory.  If (in the normal case) no previous attempt was
      # made to install this fix, the number will be 0. If (in a less
      # common situation) a previous attempt was made to install it, the
      # number will be 1.
      #
      # Whether the number is 0 or 1, no OTHER occurrences of this
      # file name should exist anywhere else under the backup root
      # directory, because this would mean that another fix is installed
      # that affects the same file. Therefore, the NumberOfFilesForThisFix
      # should be 1 if NumberOfFilesTotal is 1, or else both values should
      # be 0.
      #####################################################################
      NumberOfFilesForThisFix=0
      if [ -d $BackupDirName ] ; then
        Cmd="find $BackupDirName -type f -name $Basename | grep -F $Filename | wc -l"
        mqsilog "CMD:     $Cmd"
        NumberOfFilesForThisFix=$(find "$BackupDirName" -type f -name "$Basename" | grep -F "$Filename" | wc -l)
        if [ $NumberOfFilesForThisFix -eq 0 ] ; then
            Cmd="find $BackupDirName  -name \*.md5 -type f -exec grep -l -F $Filename {} \; | wc -l"
          mqsilog "CMD:     $Cmd"
          NumberOfFilesForThisFix=$(find "$BackupDirName"  -name \*.md5 -type f -exec grep -l -F "$Filename" {} \; | wc -l)
        fi
      fi
      mqsilog "INFO:    $NumberOfFilesForThisFix in $BackupDirName"

      #####################################################################
      # Enforce our expectations as explained above.
      #####################################################################
      if [ $NumberOfFilesTotal -ne $NumberOfFilesForThisFix ] ; then
        PathOfFile=$(find $BackupRootDirName -type f -name $Basename | grep -F $Filename)
        if [ -z "$PathOfFile" ] ; then
          PathOfFile=$(find "$BackupRootDirName"  -name \*.md5 -type f -exec grep -l -F "$Filename" {} \;)
        fi
        PatchNameT1=${PathOfFile#$BackupRootDirName}
        PatchNameT3=${PatchNameT1#/}
        PatchName=`echo "$PatchNameT3" |  awk -F'/' '{print $1}'`
        mqsilog "FAILURE: Conflict: File $Filename is already modified by FixName $PatchName."
        PatchAdded=0
        for ConflictName in $ConflictList
        do
          if [ "$ConflictName" = "$PatchName" ] ; then
             PatchAdded=1
          fi
        done

        if [ $PatchAdded -eq 0 ] ; then
          if [ $ConflictFoundM -eq 0 ] ; then
            ConflictList=$PatchName
          else
            ConflictList=$ConflictList" "$PatchName
          fi
        fi
        ConflictFoundM=1
      fi

}

####################################################################################
# FUNCTION mqsi_check_conflict_dir :
# Check if the fix is conflicting with already installed fixes
####################################################################################
mqsi_check_conflict_dir()
{

      DirName=$1
      mqsilog "INFO:    Checking directory $DirName"
      ConflictFoundS=0
      #####################################################################
      # Count the number of times that this directory is seen in the whole
      # of the backup root directory.  This number should be 0 or 1.
      #####################################################################
      Cmd="find \"$BackupRootDirName\" -type d -path \"*/$DirName\" | wc -l"
      mqsilog "CMD:     $Cmd"
      NumberOfFilesTotal=$(find "$BackupRootDirName" -type d -path "*/$DirName" | wc -l)

      # We didn't find the file in the backup tree, check the MD5s
      if [ $NumberOfFilesTotal -eq 0 ] ; then
         Cmd="find $BackupRootDirName -name '*.md5' -type f -exec grep -l -F $DirName {} \; | wc -l"
         mqsilog "CMD:     $Cmd"
         NumberOfFilesTotal=$(find "$BackupRootDirName" -name '*.md5' -type f -exec grep -l -F "$DirName" {} \; | wc -l)
      fi

      mqsilog "INFO:    $NumberOfFilesTotal in $BackupRootDirName"

      #####################################################################
      # Count the number of times that this file name is seen in "our"
      # backup directory.  If (in the normal case) no previous attempt was
      # made to install this fix, the number will be 0. If (in a less
      # common situation) a previous attempt was made to install it, the
      # number will be 1.
      #
      # Whether the number is 0 or 1, no OTHER occurrences of this
      # file name should exist anywhere else under the backup root
      # directory, because this would mean that another fix is installed
      # that affects the same file. Therefore, the NumberOfFilesForThisFix
      # should be 1 if NumberOfFilesTotal is 1, or else both values should
      # be 0.
      #####################################################################
      NumberOfFilesForThisFix=0
      if [ -d $BackupDirName ] ; then
        Cmd="find $BackupDirName -type d -path */$DirName | wc -l"
        mqsilog "CMD:     $Cmd"
        NumberOfFilesForThisFix=$(find "$BackupDirName" -type d -path "*/$DirName" | wc -l)
        if [ $NumberOfFilesForThisFix -eq 0 ] ; then
            Cmd="find $BackupDirName  -name \*.md5 -type f -exec grep -l -F $DirName {} \; | wc -l"
          mqsilog "CMD:     $Cmd"
          NumberOfFilesForThisFix=$(find "$BackupDirName"  -name \*.md5 -type f -exec grep -l -F "$DirName" {} \; | wc -l)
        fi
      fi
      mqsilog "INFO:    $NumberOfFilesForThisFix in $BackupDirName"

      #####################################################################
      # Enforce our expectations as explained above.
      #####################################################################
      if [ $NumberOfFilesTotal -ne $NumberOfFilesForThisFix ] ; then
        PathOfFile=$(find "$BackupRootDirName" -type d -path "*/$DirName")
        if [ -z "$PathOfFile" ] ; then
          PathOfFile=$(find "$BackupRootDirName"  -name \*.md5 -type f -exec grep -l -F "$DirName" {} \;)
        fi
        PatchNameT1=${PathOfFile#$BackupRootDirName}
        PatchNameT3=${PatchNameT1#/}
        PatchName=`echo "$PatchNameT3" |  awk -F'/' '{print $1}'`
        mqsilog "FAILURE: Conflict: Directory $DirName is already modified by FixName $PatchName."
        PatchAdded=0
        for ConflictName in $ConflictList
        do
          if [ "$ConflictName" = "$PatchName" ] ; then
             PatchAdded=1
          fi
        done

        if [ $PatchAdded -eq 0 ] ; then
          if [ $ConflictFoundM -eq 0 ] ; then
            ConflictList=$PatchName
          else
            ConflictList=$ConflictList" "$PatchName
          fi
        fi
        ConflictFoundM=1
      fi

}


####################################################################################
# FUNCTION mqsi_backup_installfiles :
# Back up the installation files to the backup directory.
####################################################################################
mqsi_backup_installfiles()
{

    Filename=$1

    if [ -f "$InstallDir/$Filename" ] ; then
      takebackup=1
      # Check if the file is already backed up. If it is, this run
      # is not the first run of this script.
      if [ -f "$BackupDirName/$Filename" ] ; then
        # Get first and second numbers output from cksum for the backed-up file.
        sum_backup_o=`/usr/bin/cksum "$BackupDirName/$Filename"`
        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when calculating checksum."
          exit 1
        fi
        sum_backup=`echo "$sum_backup_o" | awk '{print $1,$2}'`
        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when calculating checksum."
          exit 1
        fi
        mqsilog "INFO:    Checksum information for the backed-up file is in $BackupDirName: $sum_backup"

        # Get first and second numbers output from cksum for the already-installed file.
        sum_installed_o=`/usr/bin/cksum "$InstallDir/$Filename"`
        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when calculating checksum."
          exit 1
        fi
        sum_installed=`echo "$sum_installed_o" | awk '{print $1,$2}'`
        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when calculating checksum."
          exit 1
        fi
        mqsilog "INFO:    Checksum information for the file is in $InstallDir: $sum_installed"

        # Get first and second numbers output from cksum for our new file
        sum_fixed_o=`/usr/bin/cksum "$StageDirName/$Filename"`
        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when calculating checksum."
          exit 1
        fi
        sum_fixed=`echo "$sum_fixed_o" | awk '{print $1,$2}'`
        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when calculating checksum."
          exit 1
        fi
        mqsilog "INFO:    Checksum information for the new file is in $StageDirName: $sum_fixed"

        if [ "$sum_installed" = "$sum_fixed" ] ; then
          takebackup=0
          mqsilog "WARNING: $BackupDirName/$Filename exists. However, this appears to be"
          mqsilog "         a rerun of a previously failed run because"
          mqsilog "         $InstallDir/$Filename has the same checksum as $StageDirName/$Filename."
          mqsilog "         A previous run possibly progressed as far as"
          mqsilog "         copying the fixed file into the installation location."
          mqsilog "         No new backup will be made, but the program will continue"
          mqsilog "         to process the next file in the list, if one exists."
        elif [ "$sum_backup" = "$sum_installed" ] ; then
          takebackup=0
          mqsilog "WARNING: $BackupDirName/$Filename exists and is the same as the"
          mqsilog "         file $InstallDir/$Filename."
          mqsilog "         This appears to be a rerun of a previously failed run,"
          mqsilog "         which did progress as far as backing up the original file."
          mqsilog "         The previous run did not progress as far as copying the"
          mqsilog "         fixed file into place because the checksum for $StageDirName/$Filename"
          mqsilog "         does not match the checksum for $InstallDir/$Filename."
          mqsilog "         No new backup will be made, but the program will continue"
          mqsilog "         to process the next file in the list, if one exists."
        else
          mqsiechonlog "FAILURE: A backup cannot be taken for file $InstallDir/$Filename"
          mqsiechonlog "         because a different file $BackupDirName/$Filename"
          mqsiechonlog "         already exists from a previous run of this program. The"
          mqsiechonlog "         program cannot confirm that this is a simple rerun of a"
          mqsiechonlog "         previously failed attempt, therefore this program will now end."
          mqsiechonlog "         This program has not copied files to $InstallDir, and will"
          mqsiechonlog "         not attempt to clean up the files that it has written (for example, to"
          mqsiechonlog "         the backup location $BackupDirName)."
          mqsiechonlog "         Please tell IBM Support about this error."
          exit 1
        fi
      fi

      if [ $takebackup -eq 0 ] ; then
        mqsilog "INFO:    Not backing up $Filename"
      else
        mqsilog "INFO:    Backing up $Filename"

        runcmd mkdir -p "$BackupDirName/$(dirname "$Filename")"
        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when creating the backup directory" $BackupDirName/$(dirname "$Filename")
          exit 1
        fi

        mqsicopy "$InstallDir/$Filename" "$BackupDirName/$Filename"

        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when backing up the file $InstallDir/$Filename to" $BackupDirName/$Filename
          exit 1
        fi
      fi
    else
      mqsilog "WARNING: File $Filename does not exist; nothing to back up."
    fi

}


####################################################################################
# FUNCTION mqsi_backup_installdirs :
# Back up the installation files to the backup directory.
####################################################################################
mqsi_backup_installdirs()
{

    DirName=$1
    if [ -d "$InstallDir/$DirName" ] ; then
      # For opaque directories the only reasonable thing to do is tar up the
      # directory and calculate the checksum of that. Since the tarring of 
      # the directory is the slowest part of this process, we create a temporary
      # archive that we'll turn into the actual backup or delete it if not
      # necessary

      if [ -f "$BackupDirName/$DirName.tar" ] ; then
        # We've already got a backup file so this is a rerun of the fix installation.
        # We can be in one of the following three states:
        #
        # 1. The install tree directory matches the backup directory. So we have not
        #    previously attempted to install this directory yet.
        #
        # 2. The install tree directory matches the fix directory. So we have already
        #    successfully installed this directory.
        #
        # 3. An inconsistent state where we have perhaps managed to partially install
        #    the fix. This is a hard error as we can't know what to do in this situation.
        #
        # In all three of these situations the existing backup fix is correct and no new
        # backup needs to be taken. States 1 and 2 issue warnings however state 3 causes
        # us to exit with an error.
        

        # Calculate the checksum of the backup up directory. Note that we can the tar file into
        # cksum so that cksum doesn't print out the filename. This keeps us consistent with the
        # other two checksums we need to take since they pipe their results directly into cksum.
        sum_backup=`cat "$BackupDirName/$DirName.tar" | /usr/bin/cksum`
        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when calculating checksum of $BackupDirName/$DirName.tar."
          exit 1
        fi
        mqsilog "INFO:    Checksum information for the backed-up directory in $BackupDirName: $sum_backup"

        # Calculate the checksum of the installed directory
        sum_installed=`tar -c -f - -C "$InstallDir" "$DirName" | /usr/bin/cksum`
        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when calculating checksum for $InstallDir/$DirName."
          exit 1
        fi
        mqsilog "INFO:    Checksum information for the existing directory in $InstallDir: $sum_installed"

        # Calculate the checksum of the fix directory
        sum_fixed=`tar -c -f - -C "$StageDirName" "$DirName" | /usr/bin/cksum`
        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when calculating checksum for $StageDirName/$DirName."
          exit 1
        fi
        mqsilog "INFO:    Checksum information for the new directory in $StageDirName: $sum_fixed"

        if [ "$sum_installed" = "$sum_fixed" ] ; then
          mqsilog "WARNING: $BackupDirName/$DirName.tar exists. However, this appears to be"
          mqsilog "         a rerun of a previously failed run because"
          mqsilog "         $InstallDir/$DirName has the same checksum as $StageDirName/$DirName."
          mqsilog "         A previous run possibly progressed as far as"
          mqsilog "         copying the fixed file into the installation location."
          mqsilog "         No new backup will be made, but the program will continue"
          mqsilog "         to process the next file in the list, if one exists."
        elif [ "$sum_backup" = "$sum_installed" ] ; then
          mqsilog "WARNING: $BackupDirName/$DirName.tar exists and is the same as the"
          mqsilog "         directory $InstallDir/$DirName."
          mqsilog "         This appears to be a rerun of a previously failed run,"
          mqsilog "         which did progress as far as backing up the original file."
          mqsilog "         The previous run did not progress as far as copying the"
          mqsilog "         fixed file into place because the checksum for $StageDirName/$DirName"
          mqsilog "         does not match the checksum for $InstallDir/$DirName."
          mqsilog "         No new backup will be made, but the program will continue"
          mqsilog "         to process the next file in the list, if one exists."
        else
          mqsiechonlog "FAILURE: A backup cannot be taken for directory $InstallDir/$DirName"
          mqsiechonlog "         because a different backup archive $BackupDirName/$DirName.tar"
          mqsiechonlog "         already exists from a previous run of this program. The"
          mqsiechonlog "         program cannot confirm that this is a simple rerun of a"
          mqsiechonlog "         previously failed attempt, therefore this program will now end."
          mqsiechonlog "         This program has not copied files to $InstallDir, and will"
          mqsiechonlog "         not attempt to clean up the files that it has written (for example, to"
          mqsiechonlog "         the backup location $BackupDirName)."
          mqsiechonlog "         Please tell IBM Support about this error."
          exit 1
        fi
      
        mqsilog "INFO:    Not backing up $DirName"
      else
        mqsilog "INFO:    Backing up $DirName"

        runcmd mkdir -p "$BackupDirName/$(dirname "$DirName")"
        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when creating the backup directory" $BackupDirName/$(dirname "$DirName")
          exit 1
        fi

        runcmd tar -c -f "$BackupDirName/$DirName.tar" -C "$InstallDir" "$DirName"

        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when backing up the file $InstallDir/$DirName to" $BackupDirName/$DirName.tar
          exit 1
        fi
      fi
    else
      mqsilog "WARNING: Directory $DirName does not exist; nothing to back up."
    fi

}

####################################################################################
# FUNCTION mqsi_backup_symlinkfiles : Backup the symbolic link files.
####################################################################################
mqsi_backup_symlinkfiles()
{

    Filename=$1
    if [ -h "$InstallDir/$Filename" ] || [ -f "$InstallDir/$Filename" ] ; then
        runcmd mkdir -p "$BackupDirName/$(dirname "$Filename")"
        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when creating the backup directory" $BackupDirName/$(dirname "$Filename")
          exit 1
        fi

        mqsicopy "$InstallDir/$Filename" "$BackupDirName/$Filename"
        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when backing up the symbolic link $InstallDir/$Filename to" $BackupDirName/$Filename
          exit 1
        fi
    else
      mqsilog "WARNING: Symbolic link $Filename does not exist; nothing to back up."
    fi

}


####################################################################################
# FUNCTION mqsi_remove_dirfiles :
# Remove the directory files that are not shipped with the fix.
####################################################################################
mqsi_remove_dirfiles()
{
  IFS=$IFS_NEWLINE_SPLIT
  for Filename in $DirRemoveFileList
  do
    runcmd rm "$InstallDir/$Filename"
    rc=$?
    if [ $rc -ne 0 ] ; then
      mqsiechonlog "FAILURE: Error $rc when removing" $InstallDir/$Filename
      mqsiechonlog "         Make sure that no process is using this file."
      mqsiechonlog "         Rerun the script to complete the installation."
      mqsiechonlog "         Please tell IBM Support about this error."
      exit 1
    fi
  done

  for Symlinkname in $DirRemoveSymlinkList
  do
    runcmd rm "$InstallDir/$Symlinkname"
    rc=$?
    if [ $rc -ne 0 ] ; then
      mqsiechonlog "FAILURE: Error $rc when removing" $InstallDir/$Symlinkname
      mqsiechonlog "         Make sure that no process is using this symmlink."
      mqsiechonlog "         Rerun the script to complete the installation."
      mqsiechonlog "         Please tell IBM Support about this error."
      exit 1
    fi
  done
  IFS=$CURRENT_IFS
}


####################################################################################
# FUNCTION mqsi_install_fixfiles :
# Copy the replacement files to the installation directory
####################################################################################
mqsi_install_fixfiles()
{

    Filename=$1

    mqsilog "INFO:    Installing" $Filename

    BaseFilename=$(basename "$Filename")

    mqsicopy "$StageDirName/$Filename" "$InstallDir/$Filename"
    rc=$?
    if [ $rc -ne 0 ] ; then
      mqsiechonlog "FAILURE: Error $rc when copying "$StageDirName/$Filename" to "$InstallDir/$Filename.
      mqsiechonlog "         You might need to restore previously copied files"
      mqsiechonlog "         from the backup location $BackupDirName."
      mqsiechonlog "         Please tell IBM Support about this error."
      exit $rc
    else
      if [ $dryrun -eq 0 ] ; then
        mqsilog "INFO:    Successfully installed file "$Filename
      fi
    fi


}


####################################################################################
# FUNCTION mqsi_install_fixopaquedir:
# Copy the replacement opaque directories to the installation directory
####################################################################################
mqsi_install_fixopaquedir()
{

    DirName=$1

    mqsilog "INFO:    Installing" $DirName

    if [ -d "$InstallDir/$DirName" ]; then
      runcmd rm -rf "$InstallDir/$DirName"
      rc=$?
      if [ $rc -ne 0 ] ; then
        mqsiechonlog "FAILURE: Error $rc when removing \"$InstallDir/$DirName\" ahead of fix installation."
        mqsiechonlog "         You might need to restore previously copied files"
        mqsiechonlog "         from the backup location $BackupDirName."
        mqsiechonlog "         Please tell IBM Support about this error."
        exit $rc
      fi
    fi

    runcmd cp -R "$StageDirName/$DirName" "$InstallDir/$DirName"
    rc=$?
    if [ $rc -ne 0 ] ; then
      mqsiechonlog "FAILURE: Error $rc when copying \"$StageDirName/$DirName\" to \"$InstallDir/$Filename".
      mqsiechonlog "         You might need to restore previously copied files"
      mqsiechonlog "         from the backup location $BackupDirName."
      mqsiechonlog "         Please tell IBM Support about this error."
      exit $rc
    else
      if [ $dryrun -eq 0 ] ; then
        mqsilog "INFO:    Successfully installed directory $DirName"
      fi
    fi

  # We need to add this folder to the new directory list because we're either creating
  # it for the first time, or we just deleted the original! Either way we need to ensure
  # that the permissions are fixed-up correctly
  if [ -z "$NewDirList" ] ; then
    NewDirList=$DirName
  else
    NewDirList="$NewDirList$IFS_NEWLINE_SPLIT$DirName"
  fi

}


####################################################################################
# FUNCTION mqsi_install_symlinkfiles :
# Copy the symbolic links to the installation directory
####################################################################################
mqsi_install_symlinkfiles()
{
  IFS=$IFS_NEWLINE_SPLIT
  for Filename in $SymLinkFileList
  do
    mqsilog "INFO:    Installing symbolic link " $Filename

    BaseFilename=$(basename "$Filename")
    BaseDirName=$(dirname "$Filename")

    if [ ! -d  "$InstallDir/$BaseDirName" ] ; then

      NextBaseDirName=$BaseDirName
      while [ ! -d "$InstallDir/$NextBaseDirName" ]
      do
        PrevBaseDirName=$NextBaseDirName
        NextBaseDirName=$(dirname "$NextBaseDirName")
      done

      if [ -z "$NewDirList" ] ; then
        NewDirList=$PrevBaseDirName
      else
        NewDirList="$NewDirList$IFS_NEWLINE_SPLIT$PrevBaseDirName"
      fi

      runcmd mkdir -p "$InstallDir/$BaseDirName"
      rc=$?
      if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when creating a new installation directory" $InstallDir/$BaseDirName
          exit 1
      fi

    fi

    mqsicopy "$StageDirName/$Filename" "$InstallDir/$Filename"
    rc=$?
    if [ $rc -ne 0 ] ; then
      mqsiechonlog "FAILURE: Error $rc when copying "$StageDirName/$Filename" to "$InstallDir/$Filename.
      mqsiechonlog "         You might need to restore previously copied files"
      mqsiechonlog "         from the backup location $BackupDirName."
      mqsiechonlog "         Please tell IBM Support about this error."
      exit $rc
    else
      if [ $dryrun -eq 0 ] ; then
        mqsilog "INFO:    Successfully installed symbolic link "$Filename
      fi
    fi
  done
  IFS=$CURRENT_IFS
}


####################################################################################
# FUNCTION mqsi_set_permissions :
# Set ownership and permissions of new files copied to the install directory
####################################################################################
mqsi_set_permissions()
{

    Filename=$1

    mqsilog "INFO:    Getting the ownership of the file's directory" $InstallDir/$(dirname "$Filename")

    if [ $dryrun -eq 0 ] || [ -d "$InstallDir/$(dirname "$Filename")" ] ; then

      OwnerUser=$(ls -ld "$InstallDir/$(dirname "$Filename")" | awk '{print $3}')
      if [ -z "$OwnerUser" ] ; then
        mqsilog "WARNING: Cannot parse the user ownership. Defaulting to root."
        OwnerUser='root'
      fi
      OwnerGroup=$(ls -ld "$InstallDir/$(dirname "$Filename")" | awk '{print $4}')
      if [ -z "$OwnerGroup" ] ; then
        mqsilog "WARNING: Cannot parse the group ownership. Defaulting to mqbrkrs."
        OwnerGroup='mqbrkrs'
      fi

      mqsilog "INFO:    Setting the ownership of the new file to $OwnerUser:$OwnerGroup"

      runcmd chown "$OwnerUser:$OwnerGroup"  "$InstallDir/$Filename"
      rc=$?


      if [ $dryrun -eq 0 ] ; then
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when setting ownership $OwnerUser:$OwnerGroup on file" $Filename
          mqsiechonlog "         You might need to restore previously copied files"
          mqsiechonlog "         from the backup location $BackupDirName."
          mqsiechonlog "         Please tell IBM Support about this error."
          exit $rc
        else
          mqsilog "INFO:    Successfully set $OwnerUser:$OwnerGroup ownership on file" $Filename
        fi
      fi

    fi

    runcmd chmod 0755 "$InstallDir/$Filename"
    rc=$?
    if [ $dryrun -eq 0 ] ; then
      if [ $rc -ne 0 ] ; then
        mqsiechonlog "FAILURE: Error $rc when setting 0755 permissions on file" $Filename
        mqsiechonlog "         You might need to restore previously copied files"
        mqsiechonlog "         from the backup location $BackupDirName."
        mqsiechonlog "         Please tell IBM Support about this error."
        exit $rc
      else
        mqsilog "INFO:    Successfully set 0755 permissions on file" $Filename
      fi
    fi


}


####################################################################################
# FUNCTION mqsi_set_dir_permissions :
# Set ownership and permissions of new directories created inside the installation
# folder, recursively
####################################################################################
mqsi_set_dir_permissions()
{

    Filename=$1

    mqsilog "INFO:    Getting the ownership of the directory's parent" $InstallDir/$(dirname "$Filename")

    if [ $dryrun -eq 0 ] || [ -d "$InstallDir/$(dirname "$Filename")" ] ; then

      OwnerUser=$(ls -ld "$InstallDir/$(dirname "$Filename")" | awk '{print $3}')
      if [ -z "$OwnerUser" ] ; then
        mqsilog "WARNING: Cannot parse the user ownership. Defaulting to root."
        OwnerUser='root'
      fi
      OwnerGroup=$(ls -ld "$InstallDir/$(dirname "$Filename")" | awk '{print $4}')
      if [ -z "$OwnerGroup" ] ; then
        mqsilog "WARNING: Cannot parse the group ownership. Defaulting to mqbrkrs."
        OwnerGroup='mqbrkrs'
      fi

      mqsilog "INFO:    Setting the ownership of the new directory to $OwnerUser:$OwnerGroup"

      runcmd chown -h -R "$OwnerUser:$OwnerGroup"  "$InstallDir/$Filename"
      rc=$?


      if [ $dryrun -eq 0 ] ; then
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when setting ownership $OwnerUser:$OwnerGroup on file" $Filename
          mqsiechonlog "         You might need to restore previously copied files"
          mqsiechonlog "         from the backup location $BackupDirName."
          mqsiechonlog "         Please tell IBM Support about this error."
          exit $rc
        else
          mqsilog "INFO:    Successfully set $OwnerUser:$OwnerGroup ownership on file" $Filename
        fi
      fi

    fi

    if [ "$(uname)" = "HP-UX" ] ; then
      runcmd find "$InstallDir/$Filename" \( -type f -o -type d \) -exec chmod 0755 {} \;
    else
      runcmd chmod -f -R 0755 "$InstallDir/$Filename"
    fi

    rc=$?
    if [ $dryrun -eq 0 ] ; then
      if [ $rc -ne 0 ] ; then
        mqsiechonlog "FAILURE: Error $rc when setting 0755 permissions on file" $Filename
        mqsiechonlog "         You might need to restore previously copied files"
        mqsiechonlog "         from the backup location $BackupDirName."
        mqsiechonlog "         Please tell IBM Support about this error."
        exit $rc
      else
        mqsilog "INFO:    Successfully set 0755 permissions on file" $Filename
      fi
    fi


}


####################################################################################
# FUNCTION mqsi_post_install_uninstall_step :
# Perform any actions that are required after installation or uninstallation.
####################################################################################
mqsi_post_install_uninstall_steps()
{
  if [ "$PLATFORM" = "LinuxX64" ] &&  [ $MqsiTenFix -eq 1 ] ; then
    mqsiechonlog ""
    mqsiechonlog "-------------------------------------------------------------------------------"
    mqsiechonlog "INFO:    Performing post installation/uninstallation actions..."
    mqsiechonlog "-------------------------------------------------------------------------------"

    # Create IIB specific version of javaw if it doesn't already exist
    if [ ! -f "$InstallDir/common/jdk/jre/bin/javaw-IIB-$CurVersion" ] ; then
      mqsilog "INFO:    Copying javaw to javaw-IIB-$CurVersion."
      runcmd cp -p "$InstallDir/common/jdk/jre/bin/javaw" "$InstallDir/common/jdk/jre/bin/javaw-IIB-$CurVersion"
    fi

    # Re-initialize the Toolkit so that plug-in changes take effect.
    if [ $DoToolkitInit -eq 1 ]; then
      if [ -f "$InstallDir/tools/eclipse" ]; then
        mqsiechonlog "INFO:    Initializing Integration Toolkit."
        if [ $dryrun -eq 1 ] || [ $avoid_toolkit_init -eq 1 ] ; then
          mqsilog "INFO:    Skipping initialization of Integration Toolkit."
        else
          runcmd "$InstallDir/tools/eclipse" -initialize -clean >> "$InstallDir/mqsifixinst.log"
          rc=$?
          if [ $rc -ne 0 ] ; then
            mqsiechonlog "FAILURE: Failed to initialize Integration Toolkit in installation $InstallDir"
            exit 1
          fi
        fi
      else
        mqsiechonlog "INFO:    Integration Toolkit not installed - nothing to do."
      fi
    fi
  fi
}


####################################################################################
# FUNCTION do_install
####################################################################################
do_install()
{

  mqsiechonlog ""
  mqsiechonlog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Installing the fix. "
  mqsiechonlog "-------------------------------------------------------------------------------"


  #########################################################################
  # Copy this script to the installation directory, if needed.
  #########################################################################

  mqsifixinst_to_installdir

  #########################################################################
  # For AIX, run "slibclean"
  #########################################################################
  if [ "$PLATFORM" = "AIXPPC64" ] ; then
    if [ $avoid_root_check -eq 0 ] ; then
      runcmd slibclean
    fi
  fi

  #########################################################################
  # Generate a list of files to patch.
  # Do not include spaces in the file names.
  #########################################################################

  mqsilog ""
  mqsilog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Populating File list..."
  mqsilog "-------------------------------------------------------------------------------"

  mqsi_populate_install_filelist


  mqsilog "INFO:    Existing files to replace: " $ExistingFileList
  mqsilog "INFO:    Files to be removed: " $DirRemoveFileList
  mqsilog "INFO:    Symlinks to be removed: " $DirRemoveSymlinkList
  mqsilog "INFO:    New files to install: " $NewFileList
  mqsilog "INFO:    Symbolic links to install: " $SymLinkFileList
  mqsilog "INFO:    New directories to install:" $NewOpaqueDirList
  mqsilog "INFO:    Existing directories to replace: " $ExistingOpaqueDirList

  if [ -z "$ExistingFileList" ] && [ -z "$DirRemoveFileList" ] && [ -z "$NewFileList" ] && [ -z "$SymLinkFileList" ] && [ -z "$NewOpaqueDirList" ] && [ -z "$ExistingOpaqueDirList" ] ; then
    mqsiechonlog "FAILURE: There are no files shipped with the fix; therefore the fix will not be installed."
    mqsiechonlog "         Contact IBM support to validate the fix."
    exit 1
  fi

  #########################################################################
  # Check that the patch does not conflict with an existing patch.
  #########################################################################
  mqsilog ""
  mqsilog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Conflict checking..."
  mqsilog "-------------------------------------------------------------------------------"

  if [ -d "$BackupRootDirName" ] ; then

    mqsilog "INFO:    $BackupRootDirName directory exists."
    mqsilog "INFO:    Checking for conflicting files that are already installed."

    ConflictFoundM=0
    ConflictList=''

    IFS=$IFS_NEWLINE_SPLIT
    for Filename in $ExistingFileList
    do
      mqsi_check_conflict "$Filename"
    done

    for Filename in $DirRemoveFileList
    do
      mqsi_check_conflict "$Filename"
    done

    for Filename in $DirRemoveSymlinkList
    do
      mqsi_check_conflict "$Filename"
    done

    for Filename in $SymLinkFileList
    do
      mqsi_check_conflict "$Filename"
    done

    for Filename in $ExistingOpaqueDirList
    do
      mqsi_check_conflict_dir "$Filename"
    done

    IFS=$CURRENT_IFS

    if [ $ConflictFoundM -eq 1 ] ; then
      mqsiechonlog "FAILURE: If FixName $FixName is not a combined fix, you must obtain a combined fix from IBM Support."
      mqsiechonlog "         The Combined Fix should include the FixName(s) :"
      for FixNameTemp in $ConflictList
      do
       mqsiechonlog "           $FixNameTemp"
      done
      mqsiechonlog "         You must uninstall the above FixName(s) before you can install the combined fix."
      exit 1
    fi

    mqsilog "INFO:    No conflicting files found."


  else
    mqsilog "INFO:    Backup root directory $BackupRootDirName did not exist before this fix.  This directory will be created soon."
    mqsilog "INFO:    Removing any existing fix backup directories and existing mqsifixinst.dat file."
    runcmd rm -rf "$InstallDir/fix-backups.*"
    runcmd rm -f "$InstallDir/mqsifixinst.dat"
    firstinstall=1
  fi



  StageDirName=$OriginalDir
  DestDirName=$InstallDir


  #########################################################################
  # Create a backup of all existing files before installation begins.
  #########################################################################

  mqsilog ""
  mqsilog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Backing up existing files..."
  mqsilog "-------------------------------------------------------------------------------"

  mqsilog "INFO:    Backing up product files to new directory $BackupDirName"

  IFS=$IFS_NEWLINE_SPLIT
  for Filename in $ExistingFileList
  do
    mqsi_backup_installfiles "$Filename"
  done

  for Filename in $DirRemoveFileList
  do
    mqsi_backup_installfiles "$Filename"
  done

  for DirName in $ExistingOpaqueDirList
  do
    mqsi_backup_installdirs "$DirName"
  done

  for Filename in $DirRemoveSymlinkList
  do
    mqsi_backup_symlinkfiles "$Filename"
  done

  for Filename in $SymLinkFileList
  do
    mqsi_backup_symlinkfiles "$Filename"
  done
  IFS=$CURRENT_IFS

  if [ ! -d "$BackupDirName" ] ; then
    mqsilog "INFO:    Backup directory is not created yet; creating the backup directory now."
    runcmd mkdir -p "$BackupDirName"
    if [ $? -ne 0 ] ; then
      mqsilog "WARNING: Error creating the backup directory" $BackupDirName
    fi
  fi

  #########################################################################
  # Take ls -ilR listing for later reference
  #########################################################################
  mqsilog "CMD:     ls -ilR $InstallDir > $BackupDirName/beforeInstall.log"
  if [ $dryrun -eq 0 ] ; then
    ls -ilR "$InstallDir" > "$BackupDirName/beforeInstall.log"
  fi

  #########################################################################
  # Remove each file from the product directory that is not in the fix-dir
  #########################################################################
  mqsilog ""
  mqsilog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Removing non-shipped directory files...."
  mqsilog "-------------------------------------------------------------------------------"

  mqsi_remove_dirfiles


  #########################################################################
  # Install each file. Copying on top of the installation file helps
  # to keep the permission and ownership intact.
  #########################################################################
  mqsilog ""
  mqsilog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Installing replacement files...."
  mqsilog "-------------------------------------------------------------------------------"

  IFS=$IFS_NEWLINE_SPLIT
  for Filename in $ExistingFileList
  do
    mqsi_install_fixfiles "$Filename"
  done

  for DirName in $ExistingOpaqueDirList
  do
    mqsi_install_fixopaquedir "$DirName"
  done

  for DirName in $NewOpaqueDirList
  do

    BaseDirName=$(dirname "$DirName")

    if [ ! -d  "$InstallDir/$BaseDirName" ] ; then

      NextBaseDirName=$BaseDirName
      while [ ! -d "$InstallDir/$NextBaseDirName" ]
      do
        PrevBaseDirName=$NextBaseDirName
        NextBaseDirName=$(dirname "$NextBaseDirName")
      done

      if [ -z "$NewDirList" ] ; then
        NewDirList=$PrevBaseDirName
      else
        NewDirList="$NewDirList$IFS_NEWLINE_SPLIT$PrevBaseDirName"
      fi

      runcmd mkdir -p "$InstallDir/$BaseDirName"
      rc=$?
      if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when creating a new installation directory" $InstallDir/$BaseDirName
          exit 1
      fi
    fi

    mqsi_install_fixopaquedir "$DirName"
  done

  for Filename in $NewFileList
  do

    BaseDirName=$(dirname "$Filename")

    if [ ! -d  "$InstallDir/$BaseDirName" ] ; then

      NextBaseDirName=$BaseDirName
      while [ ! -d "$InstallDir/$NextBaseDirName" ]
      do
        PrevBaseDirName=$NextBaseDirName
        NextBaseDirName=$(dirname "$NextBaseDirName")
      done

      if [ -z "$NewDirList" ] ; then
        NewDirList=$PrevBaseDirName
      else
        NewDirList="$NewDirList$IFS_NEWLINE_SPLIT$PrevBaseDirName"
      fi

      runcmd mkdir -p "$InstallDir/$BaseDirName"
      rc=$?
      if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Error $rc when creating a new installation directory" $InstallDir/$BaseDirName
          exit 1
      fi
    fi

    mqsi_install_fixfiles "$Filename"

  done
  IFS=$CURRENT_IFS

  if [ ! -z "$SymLinkFileList" ] ; then
    mqsi_install_symlinkfiles
  fi



  #########################################################################
  # Set the permissions if a new file is installed.
  #########################################################################
  mqsilog ""
  mqsilog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Setting the ownership and permissions of new files (if any)..."
  mqsilog "-------------------------------------------------------------------------------"

  IFS=$IFS_NEWLINE_SPLIT
  for BaseDirName in $NewDirList
  do
    mqsi_set_dir_permissions "$BaseDirName"
  done

  for Filename in $NewFileList
  do
    mqsi_set_permissions "$Filename"
  done

  for Filename in $PermissionFileList
  do
    mqsi_set_permissions "$Filename"
  done
  IFS=$CURRENT_IFS

  mqsilog ""
  mqsilog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Updating fix information..."
  mqsilog "-------------------------------------------------------------------------------"

  #########################################################################
  # This script can be used to uninstall the item that was just installed.
  # The README.txt file describes what this fix is, and what it contains.
  # Failures to copy these files are warnings only because the main job is
  # already complete.
  #########################################################################
  mqsilog "INFO:    Copying the script and readme files to the backup directory."

  runcmd cp "$ThisScript" "$BackupDirName/$(basename "$ThisScript")"
  if [ $? -ne 0 ] ; then
    mqsilog "WARNING: Cannot copy" $(basename "$ThisScript")
  fi
  runcmd mkdir -p "$BackupDirName/readmes"
  if [ $? -ne 0 ] ; then
    mqsilog "WARNING: Error issued when creating the readmes directory inside backup directory" $BackupDirName
  fi
  runcmd cp "$ReadmeFile" "$BackupDirName/readmes/$(basename "$ReadmeFile")"
  if [ $? -ne 0 ] ; then
    mqsilog "WARNING: Cannot copy" $(basename "$ReadmeFile")
  fi

  runcmd cp "$MqsifixinstDatFile" "$BackupDirName/readmes/$(basename "$MqsifixinstDatFile")"
  if [ $? -ne 0 ] ; then
    mqsilog "WARNING: Cannot copy" $(basename "$MqsifixinstDatFile")
  fi

  runcmd cp "$MqsifixinstMdFile" "$BackupDirName/readmes/$(basename "$MqsifixinstMdFile")"
  if [ $? -ne 0 ] ; then
    mqsilog "WARNING: Cannot copy" $(basename "$MqsifixinstMdFile")
  fi

  #########################################################################
  # Take ls -ilR listing for later reference.  (Redirection operator
  # means we cannot use runcmd).
  #########################################################################
  mqsilog "CMD:     ls -ilR $InstallDir > $BackupDirName/afterInstall.log"
  if [ $dryrun -eq 0 ] ; then
    ls -ilR "$InstallDir" > "$BackupDirName/afterInstall.log"
  fi

  mqsilog "INFO:    Setting 0755 permissions to all of the files under $BackupDirName"
  if [ "$(uname)" = "HP-UX" ] ; then
    runcmd find "$BackupDirName" \( -type f -o -type d \) -exec chmod 0755 {} \;
  else
    runcmd chmod -f -R 0755 "$BackupDirName"
  fi

  if [ $? -ne 0 ] ; then
    mqsilog "WARNING: Cannot set 755 permission for files under $BackupDirName"
  fi

  #########################################################################
  # Store the fix name for later reference (and use by ISA data collector).
  # (Redirection operator means we cannot use runcmd).
  #########################################################################
  mqsilog "INFO:    Storing the fix name."
  mqsilog "CMD:     echo \"$FixName # $Date\" >> $InstallDir/mqsifixinst.dat"
  if [ $dryrun -eq 0 ] ; then
    if [ $DotXFixName -eq 1 ] ; then
      echo "$FixName($CurVersion) # $Date" >> "$InstallDir/mqsifixinst.dat"
    else
      echo "$FixName # $Date" >> "$InstallDir/mqsifixinst.dat"
    fi
  fi


  #########################################################################
  # Determine the owner of the install directory
  #########################################################################
  OwnerUser=$(ls -ld "$InstallDir" | awk '{print $3}')
  if [ -z "$OwnerUser" ] ; then
    mqsilog "WARNING: Cannot parse the user ownership. Defaulting to root."
    OwnerUser='root'
  fi
  OwnerGroup=$(ls -ld "$InstallDir" | awk '{print $4}')
  if [ -z "$OwnerGroup" ] ; then
    mqsilog "WARNING: Cannot parse the group ownership. Defaulting to mqbrkrs."
    OwnerGroup='mqbrkrs'
  fi


  if [ $dryrun -eq 0 ] && [ $firstinstall -eq 1 ] ; then

    mqsilog "INFO:    This is the first installation of a fix; therefore, setting the permission and ownership of fix installer resources."
    mqsilog "INFO:    Setting the permissions of all fix installer resources. Ignore any errors that occur."

    runcmd chmod 0664 "$InstallDir/mqsifixinst.dat"
    runcmd chmod 0664 "$InstallDir/mqsifixinst.log"
    runcmd chmod 0774 "$InstallDir/mqsifixinst.sh"
    runcmd chmod 0775 "$BackupRootDirName"

    mqsilog "INFO:    Setting the ownership of all fix installer resources to be the same as the installation directory."

    runcmd chown "$OwnerUser:$OwnerGroup" "$InstallDir/mqsifixinst.dat"
    runcmd chown "$OwnerUser:$OwnerGroup" "$InstallDir/mqsifixinst.log"
    runcmd chown "$OwnerUser:$OwnerGroup" "$InstallDir/mqsifixinst.sh"
    runcmd chown -h -R "$OwnerUser:$OwnerGroup" "$BackupRootDirName"
  elif [ $dryrun -eq 0 ] ; then
    mqsilog "INFO:    Setting the ownership of the backup files in the installation directory."
    runcmd chown -h -R "$OwnerUser:$OwnerGroup" "$BackupDirName"
  fi


  #########################################################################
  # Perform post-installation actions
  #########################################################################

  # See if we need to re-initialize the toolkit
  if [ $DoToolkitInit -eq 0 ] && [ `grep "tools/\|common/" "$MqsifixinstMdFile"  2>/dev/null | wc -l` -gt 0 ] ; then
    DoToolkitInit=1
  fi

  mqsi_post_install_uninstall_steps

}


####################################################################################
# FUNCTION mqsi_populate_uninstall_filelist : Create the uninstallation file list
####################################################################################
mqsi_populate_uninstall_filelist()
{

  while IFS=";" read filmd filname filsize
  do
    if [ "$filmd" !=  "null" ] && [ "$filmd" !=  "directory" ] && [ "$filmd" !=  "symlink" ] && [ "$filmd" != "opaque_dir" ] ; then
      if [ -z "$UFileList" ] ; then
        UFileList=$filname
      else
        UFileList="$UFileList$IFS_NEWLINE_SPLIT$filname"
      fi
    fi

    if [ "$filmd" =  "directory" ] ; then
      if [ -z "$UDirList" ] ; then
        UDirList=$filname
      else
        UDirList="$UDirList$IFS_NEWLINE_SPLIT$filname"
      fi
    fi

    if [ "$filmd" = "opaque_dir" ] ; then
      # HPUX and Solaris are too painful, and we should only be using opaque_dir fixes for things
      # that aren't shipped on these platfroms, e.g. node_modules
      if [ "$(uname)" = "SunOS" ] || [ "$(uname)" = "HP-UX" ] ; then
        mqsiechonlog "FAILURE: Directory '$filname' mentioned in the fix md5 file is an opaque directory, which is not supported by this script."
        mqsiechonlog "         Installation can be performed manually by following the steps in the fix readme file."
        mqsiechonlog "         Please tell IBM Support that this fix has an inappropriate directory type in it."
        exit 1
      fi
      
      if [ -z "$UOpaqueDirList" ] ; then
        UOpaqueDirList=$filname
      else
        UOpaqueDirList="$UOpaqueDirList$IFS_NEWLINE_SPLIT$filname"
      fi
    fi

    if [ "$filmd" =  "symlink" ] ; then
      if [ -z "$USymLinkFileList" ] ; then
        USymLinkFileList=$filname
      else
        USymLinkFileList="$USymLinkFileList$IFS_NEWLINE_SPLIT$filname"
      fi
    fi
  done < "$MqsifixinstMdFile"

  IFS=$IFS_NEWLINE_SPLIT
  for DirName in $UDirList
  do
    if [ -d "$BackupDirName/$DirName" ] ; then

      AllDirFiles=$(find "$BackupDirName/$DirName" -type f -o -type l )

      for EachDirFiles in $AllDirFiles
      do
        EachDirFilesRl0=${EachDirFiles#$BackupDirName}
        EachDirFilesRl=${EachDirFilesRl0#/}
        if [ ! -f "$InstallDir/$EachDirFilesRl" ] && [ ! -h "$InstallDir/$EachDirFilesRl" ] ; then
          if [ -h "$BackupDirName/$EachDirFilesRl" ] ; then
            mqsilog "WARNING: Symbolic link $EachDirFilesRl present in the backup directory is not present in the installed directory."
          else
            mqsilog "WARNING: File $EachDirFilesRl present in the backup directory is not present in the installed directory."
          fi
          if [ -z "$UNewFileList" ] ; then
            UNewFileList=$EachDirFilesRl
          else
            UNewFileList="$UNewFileList$IFS_NEWLINE_SPLIT$EachDirFilesRl"
          fi
        else
          # Look to see if we have any autogenerated files which are backed up, and in the installation directory, but are not in the fix md5, as we need to restore those too
          Found=0
          for FileName in $UFileList
          do
            if [ "$FileName" = "$EachDirFilesRl" ] ; then
              Found=1
            fi
          done
          for SymlinkName in $USymLinkFileList
          do
            if [ "$SymlinkName" = "$EachDirFilesRl" ] ; then
              Found=1
            fi
          done
          if [ "$Found" = "0" ] ; then
            if [ -h "$InstallDir/$EachDirFilesRl" ] ; then
              mqsilog "WARNING: Symbolic link $EachDirFilesRl present in the backup and installation directories is not in the fix md5 file. "
              if [ -z "$USymLinkFileList" ] ; then
                USymLinkFileList=$EachDirFilesRl
              else
                USymLinkFileList="$USymLinkFileList$IFS_NEWLINE_SPLIT$EachDirFilesRl"
              fi
            else
              mqsilog "WARNING: File $EachDirFilesRl present in the backup and installation directories is not in the fix md5 file. "
              if [ -z "$UFileList" ] ; then
                UFileList=$EachDirFilesRl
              else
                UFileList="$UFileList$IFS_NEWLINE_SPLIT$EachDirFilesRl"
              fi
            fi
          fi
        fi
      done
    fi
  done

  for Filename in $USymLinkFileList
  do

    if [ -h "$BackupDirName/$Filename" ] || [ -f "$BackupDirName/$Filename" ] ; then
      if [ -z "$USymLinkExistingList" ] ; then
        USymLinkExistingList=$Filename
      else
        USymLinkExistingList="$USymLinkExistingList$IFS_NEWLINE_SPLIT$Filename"
      fi
    else
      if [ -z "$USymLinkRemoveList" ] ; then
        USymLinkRemoveList=$Filename
      else
        USymLinkRemoveList="$USymLinkRemoveList$IFS_NEWLINE_SPLIT$Filename"
      fi
    fi

    if [ ! -h $InstallDir/$Filename ] ; then
      mqsiechonlog "FAILURE: Symbolic link $Filename mentioned in the fix md5 file does not exist in the installation directory."
      exit 1
    fi

  done

  for Filename in $UFileList
  do
    if [ ! -f "$BackupDirName/$Filename" ] && [ ! -h "$BackupDirName/$Filename" ] ; then
      mqsilog "WARNING: File $Filename mentioned in the fix md5 file does not exist in the backup directory; must be a new file."
      if [ -z "$URemoveFileList" ] ; then
        URemoveFileList=$Filename
      else
        URemoveFileList="$URemoveFileList$IFS_NEWLINE_SPLIT$Filename"
      fi
    else
      if [ -z "$UExistingFileList" ] ; then
        UExistingFileList=$Filename
      else
        UExistingFileList="$UExistingFileList$IFS_NEWLINE_SPLIT$Filename"
      fi
    fi

    if [ ! -f "$InstallDir/$Filename" ]  && [ ! -h "$InstallDir/$Filename" ] ; then
      mqsiechonlog "FAILURE: File $Filename mentioned in the fix md5 file does not exist in the installation directory."
      exit 1
    fi
  done

  for DirName in $UOpaqueDirList
  do
    if [ ! -f "$BackupDirName/$DirName.tar" ] ; then
      mqsilog "WARNING: Directory $DirName mentioned in the fix MD5 file does not exist in the backup directory; must be a new directory."
      if [ -z "$URemoveOpaqueDirList" ] ; then
        URemoveOpaqueDirList=$DirName
      else
        URemoveOpaqueDirList="$DirName$IFS_NEWLINE_SPLIT$DirName"
      fi
    else
      if [ -z "$UExistingOpaqueDirList" ] ; then
        UExistingOpaqueDirList=$DirName
      else
        UExistingOpaqueDirList="$UExistingOpaqueDirList$IFS_NEWLIT_SPLIT$DirName"
      fi
    fi

    if [ ! -d "$InstallDir/$DirName" ] ; then
      mqsiechonlog "FAILURE: Directory $DirName mentioned in the fix MD5 file does not exist in the installation directory."
      exit 1
    fi
  done

  IFS=$CURRENT_IFS
}


####################################################################################
# FUNCTION mqsi_backup_fixfiles :
# Back up the installed files to the uninstallation backup directory before
# performing the uninstallation
####################################################################################
mqsi_backup_fixfiles()
{
    Filename=$1

    mqsilog "INFO:    Backing up" $Filename

    runcmd mkdir -p "$UninstallBackupDirName/$(dirname "$Filename")"
    rc=$?
    if [ $rc -ne 0 ] ; then
      mqsiechonlog "FAILURE: Error $rc when creating the backup directory" $UninstallBackupDirName/$(dirname "$Filename")
      exit 1
    fi

    mqsicopy "$InstallDir/$Filename" "$UninstallBackupDirName/$Filename"
    rc=$?
    if [ $rc -ne 0 ] ; then
      mqsiechonlog "FAILURE: Error $rc when backing up the file $InstallDir/$Filename to" $UninstallBackupDirName/$Filename
      exit 1
    fi

}


####################################################################################
# FUNCTION mqsi_backup_fixdirs :
# Back up the installed directory to the uninstallation backup directory before
# performing the uninstallation
####################################################################################
mqsi_backup_fixdirs()
{
    DirName=$1

    mqsilog "INFO:    Backing up" $DirName

    runcmd mkdir -p "$UninstallBackupDirName/$(dirname "$DirName")"
    rc=$?
    if [ $rc -ne 0 ] ; then
      mqsiechonlog "FAILURE: Error $rc when creating the backup directory" $UninstallBackupDirName/$(dirname "$Filename")
      exit 1
    fi

    runcmd tar -c -f "$UninstallBackupDirName/$DirName.tar" -C "$InstallDir" "$DirName"
    rc=$?
    if [ $rc -ne 0 ] ; then
      mqsiechonlog "FAILURE: Error $rc when backing up the directory $InstallDir/$DirName to $UninstallBackupDirName/$DirName.tar"
      exit 1
    fi

}


####################################################################################
# FUNCTION mqsi_restore_origfiles :
# Restore the original files from the backup directory as part of uninstallation.
####################################################################################
mqsi_restore_origfiles()
{

      Filename=$1
      mqsilog "INFO:    Restoring $Filename from backup location $BackupDirName"
      mqsicopy "$BackupDirName/$Filename" "$InstallDir/$Filename"
      rc=$?
      if [ $rc -ne 0 ] ; then
        mqsiechonlog "FAILURE: Error $rc when restoring the file $Filename to $InstallDir/$Filename."
        mqsiechonlog "         You might need to roll back previously restored files"
        mqsiechonlog "         from the backup location $UninstallBackupDirName."
        mqsiechonlog "         Please tell IBM Support about this error."
        exit $rc
      else
        if [ $dryrun -eq 0 ] ; then
          mqsilog "INFO:    Successfully restored the file "$Filename
        fi
      fi
}


####################################################################################
# FUNCTION mqsi_restore_origdirs :
# Restore the original directory from the backup directory as part of uninstallation.
####################################################################################
mqsi_restore_origdirs()
{
      DirName=$1
      mqsilog "INFO:    Restoring $DirName from backup location $BackupDirName"
      runcmd rm -rf "$InstallDir/$DirName"
      if [ $rc -ne 0 ]; then
        mqsiechonlog "FAILURE: Error $rc when removing the existing $InstallDir/$DirName directory."
        mqsiechonlog "         You might need to roll back previously restored files"
        mqsiechonlog "         from the backup location $UninstallBackupDirName."
        mqsiechonlog "         Please tell IBM Support about this error."
        exit $rc
      fi
      
      runcmd tar -x -f "$BackupDirName/$DirName.tar" -C "$InstallDir"
      rc=$?
      if [ $rc -ne 0 ] ; then
        mqsiechonlog "FAILURE: Error $rc when restoring the directory $DirName to $InstallDir/$DirName."
        mqsiechonlog "         You might need to roll back previously restored files"
        mqsiechonlog "         from the backup location $UninstallBackupDirName."
        mqsiechonlog "         Please tell IBM Support about this error."
        exit $rc
      else
        if [ $dryrun -eq 0 ] ; then
          mqsilog "INFO:    Successfully restored the directory $DirName"
        fi
      fi
}


####################################################################################
# FUNCTION mqsi_remove_newfiles :
# Deletes the new files, which are shipped with the fix, from the product directory.
####################################################################################
mqsi_remove_newfiles()
{

    Filename=$1

    BaseDirName=$(dirname "$Filename")

    if [ ! -d  "$BackupDirName/$BaseDirName" ] ; then
      if [ -z "$URemoveDirList" ] ; then
        URemoveDirList=$BaseDirName
      else
        URemoveDirList="$URemoveDirList$IFS_NEWLINE_SPLIT$BaseDirName"
      fi
    fi

    runcmd rm "$InstallDir/$Filename"
    rc=$?
    if [ $rc -ne 0 ] ; then
      mqsiechonlog "FAILURE: Error $rc when removing" $InstallDir/$Filename
      mqsiechonlog "         To undo the uninstallation, roll back previously restored files (if any exist)"
      mqsiechonlog "         from the backup location $UninstallBackupDirName"
      mqsiechonlog "         into the installation directory $InstallDir."
      mqsiechonlog "         Otherwise, to complete the uninstallation manually, complete these steps:"
      mqsiechonlog "         1. Check the reason for the failure."
      mqsiechonlog "         2. Remove the files that are new, and that were shipped with this fix,"
      mqsiechonlog "         from the installation directory $InstallDir."
      mqsiechonlog "         Please tell IBM Support about this error."
      exit 1
    fi

}

####################################################################################
# FUNCTION mqsi_remove_newdirs :
# Deletes the new files, which are shipped with the fix, from the product directory.
####################################################################################
mqsi_remove_newdirs()
{
    DirName=$1
    BaseDirName=$(dirname "$DirName")
    if [ ! -d "$BackupDirName/$BaseDirName" ] ; then
      if [ -z "$URemoveDirList" ] ; then
        URemoveDirList=$BaseDirName
      else
        URemoveDirList="$URemoveDirList$IFS_NEWLINE_SPLIT$BaseDirName"
      fi
    fi

    runcmd rm -rf "$InstallDir/$DirName"
    rc=$?
    if [ $rc -ne 0 ] ; then
      mqsiechonlog "FAILURE: Error $rc when removing $InstallDir/$DirName"
      mqsiechonlog "         To undo the uninstallation, roll back previously restored files (if any exist)"
      mqsiechonlog "         from the backup location $UninstallBackupDirName"
      mqsiechonlog "         into the installation directory $InstallDir."
      mqsiechonlog "         Otherwise, to complete the uninstallation manually, complete these steps:"
      mqsiechonlog "         1. Check the reason for the failure."
      mqsiechonlog "         2. Remove the files that are new, and that were shipped with this fix,"
      mqsiechonlog "         from the installation directory $InstallDir."
      mqsiechonlog "         Please tell IBM Support about this error."
      exit 1
    fi

}


####################################################################################
# FUNCTION mqsi_set_uninstall_permissions : Set permissions of restored files
####################################################################################
mqsi_set_uninstall_permissions()
{

    Filename=$1

    mqsilog "INFO:    Getting the ownership of the file's directory" $InstallDir/$(dirname "$Filename")

    OwnerUser=$(ls -ld "$InstallDir/$(dirname "$Filename")" | awk '{print $3}')
    if [ -z "$OwnerUser" ] ; then
      mqsilog "WARNING: Cannot parse the user ownership. Defaulting to root."
      OwnerUser='root'
    fi
    OwnerGroup=$(ls -ld "$InstallDir/$(dirname "$Filename")" | awk '{print $4}')
    if [ -z "$OwnerGroup" ] ; then
      mqsilog "WARNING: Cannot parse the group ownership. Defaulting to mqbrkrs."
      OwnerGroup='mqbrkrs'
    fi

    mqsilog "INFO:    Setting the ownership of the new restored file to $OwnerUser:$OwnerGroup"

    runcmd chown -h "$OwnerUser:$OwnerGroup" "$InstallDir/$Filename"
    rc=$?

    if [ $dryrun -eq 0 ] ; then
      if [ $rc -ne 0 ] ; then
        mqsiechonlog "FAILURE: Error $rc when setting ownership $OwnerUser:$OwnerGroup on file" $Filename
        mqsiechonlog "         To undo the uninstallation, roll back previously restored files (if any exist)"
        mqsiechonlog "         from the backup location $UninstallBackupDirName"
        mqsiechonlog "         into the installation directory $InstallDir."
        mqsiechonlog "         Otherwise, to complete the uninstallation manually, complete these steps:"
        mqsiechonlog "         1. Check the reason for the failure."
        mqsiechonlog "         2. Make sure that the permission and ownership of the restored files are correct."
        mqsiechonlog "         Please tell IBM Support about this error."
        exit $rc
      else
        mqsilog "INFO:    Successfully set $OwnerUser:$OwnerGroup ownership on file" $Filename
      fi
    fi

    if [ "$(uname)" = "HP-UX" ] ; then
      runcmd chmod 0755 "$InstallDir/$Filename"
    else
      runcmd chmod -f 0755 "$InstallDir/$Filename"
    fi

    rc=$?
    if [ $dryrun -eq 0 ] ; then
      if [ $rc -ne 0 ] ; then
        mqsiechonlog "FAILURE: Error $rc when setting 0755 permissions on file" $Filename
        mqsiechonlog "         To undo the uninstallation, roll back previously restored files (if any exist)"
        mqsiechonlog "         from backup location $UninstallBackupDirName"
        mqsiechonlog "         into the installation directory $InstallDir."
        mqsiechonlog "         Otherwise, to complete the uninstallation manually, complete these steps:"
        mqsiechonlog "         1. Check the reason for the failure."
        mqsiechonlog "         2. Make sure that the permission and ownership of the restored files are correct."
        mqsiechonlog "         Please tell IBM Support about this error."
        exit $rc
      else
        mqsilog "INFO:    Successfully set 0755 permissions on file" $Filename
      fi
    fi

}


####################################################################################
# FUNCTION do_uninstall : Perform fix uninstallation.
####################################################################################
do_uninstall()
{
  if [ $uninstall_all -eq 0 ] ; then
    mqsiechonlog ""
    mqsiechonlog "-------------------------------------------------------------------------------"
    mqsiechonlog "INFO:    Uninstalling the fix."
    mqsiechonlog "-------------------------------------------------------------------------------"
  fi

  if [ "$(uname)" = "AIX" ] ; then
    if [ $avoid_root_check -eq 0 ] ; then
      runcmd slibclean
    fi
  fi

  #########################################################################
  # Check that the installation was successful. The backup directory
  # should exist, and a copy of this script should have been copied to it,
  # if the installation completed successfully.
  #########################################################################
  if [ ! -d "$BackupDirName" ] ; then
    mqsiechonlog "FAILURE: Directory $BackupDirName does not exist."
    mqsiechonlog "         Uninstallation cannot continue."
    exit 1
  fi

  if [ ! -f "$BackupDirName/$(basename "$ThisScript")" ] ; then
    mqsiechonlog "FAILURE: File" $BackupDirName/$(basename "$ThisScript") "does not exist."
    mqsiechonlog "         Uninstallation cannot continue."
    exit 1
  fi

  mqsilog "INFO:    $BackupDirName directory exists. Checking for the existence of backed-up files."

  #########################################################################
  # Generate a list of files to uninstall. Do not include spaces in the
  # file names.
  #########################################################################
  cd "$BackupDirName"
  if [ $? -ne 0 ] ; then
    mqsiechonlog "FAILURE: Cannot change directory to $BackupDirName"
    exit 1
  fi

  MqsifixinstMdFile="$BackupDirName/readmes/$FixName.md5"

  if [ ! -f "$MqsifixinstMdFile" ] ; then
    mqsiechonlog "FAILURE: File" $MqsifixinstMdFile "does not exist."
    mqsiechonlog "         Investigate why this file is not present in the backup directory."
    exit 1
  fi

  mqsilog ""
  mqsilog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Populating uninstallation file list..."
  mqsilog "-------------------------------------------------------------------------------"

  mqsi_populate_uninstall_filelist


  mqsilog "INFO:    Existing files to restore: " $UExistingFileList
  mqsilog "INFO:    New files to be removed: " $URemoveFileList
  mqsilog "INFO:    Deleted files to be restored: " $UNewFileList
  mqsilog "INFO:    Symbolic links to uninstalled: " $USymLinkFileList
  mqsilog "INFO:    Directories to be removed: " $URemoveOpaqueDirList
  mqsilog "INFO:    Directories to be restored: " $UExistingOpaqueDirList

  # See if we need to re-initialize the toolkit at the end
  if [ $DoToolkitInit -eq 0 ] && [ `grep "tools/\|common/" "$MqsifixinstMdFile"  2>/dev/null | wc -l` -gt 0 ] ; then
    DoToolkitInit=1
  fi

  #########################################################################
  # Run everything else by using full paths from the original location.
  #########################################################################
  cd "$OriginalDir"
  if [ $? -ne 0 ] ; then
    mqsiechonlog "FAILURE: Cannot change the directory to $OriginalDir"
    exit 1
  fi

  #########################################################################
  # If this fix name has been uninstalled before, the
  # .uninstall/FixName directory is no longer needed; remove it.
  #########################################################################
  mqsilog "INFO:    Checking for the presence of uninstallation backup directory $UninstallBackupDirName"
  if [ -d "$UninstallBackupDirName" ] ; then
    mqsilog "INFO:    Removing the old uninstallation directory $UninstallBackupDirName"
    runcmd rm -r "$UninstallBackupDirName"
  else
    mqsilog "INFO:    $UninstallBackupDirName does not exist."
  fi


  #########################################################################
  # Create a backup of all existing files before uninstallation.
  #########################################################################
  mqsilog ""
  mqsilog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Backing up existing files..."
  mqsilog "-------------------------------------------------------------------------------"
  mqsilog "INFO:    Backing up product files to new directory $UninstallBackupDirName"

  IFS=$IFS_NEWLINE_SPLIT
  for Filename in $UExistingFileList
  do
     mqsi_backup_fixfiles "$Filename"
  done

  for Filename in $URemoveFileList
  do
     mqsi_backup_fixfiles "$Filename"
  done

  for DirName in $UExistingOpaqueDirList
  do
    mqsi_backup_fixdirs "$DirName"
  done

  for DirName in $URemoveOpaqueDirList
  do
    mqsi_backup_fixdirs "$DirName"
  done

  IFS=$CURRENT_IFS

  if [ ! -d "$UninstallBackupDirName" ] ; then
    runcmd mkdir -p "$UninstallBackupDirName"
  fi



  #########################################################################
  # Take ls -ilR listing for later reference
  #########################################################################
  mqsilog "CMD:     ls -ilR $InstallDir > $UninstallBackupDirName/beforeUninstall.log"
  if [ $dryrun -eq 0 ] ; then
    ls -ilR "$InstallDir" > "$UninstallBackupDirName/beforeUninstall.log"
  fi

  #########################################################################
  # Now restore each file. Copying the original files on top of the already
  # present files helps to keep the permission and ownership intact.
  #########################################################################
  mqsilog ""
  mqsilog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Restoring original files..."
  mqsilog "-------------------------------------------------------------------------------"

  IFS=$IFS_NEWLINE_SPLIT
  for Filename in $UExistingFileList
  do
    mqsi_restore_origfiles "$Filename"
  done

  for Filename in $UNewFileList
  do
    mqsi_restore_origfiles "$Filename"
  done

  for Filename in $USymLinkExistingList
  do
    mqsi_restore_origfiles "$Filename"
  done

  for DirName in $UExistingOpaqueDirList
  do
    mqsi_restore_origdirs "$DirName"
  done
  IFS=$CURRENT_IFS

  #########################################################################
  # Remove from the product directory the newer files that are shipped with
  # this fix.
  #########################################################################
  mqsilog ""
  mqsilog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Removing new files..."
  mqsilog "-------------------------------------------------------------------------------"

  IFS=$IFS_NEWLINE_SPLIT
  for Filename in $URemoveFileList
  do
     mqsi_remove_newfiles "$Filename"
  done

  for Filename in $USymLinkRemoveList
  do
     mqsi_remove_newfiles "$Filename"
  done

  for DirName in $URemoveOpaqueDirList
  do
    mqsi_remove_newdirs "$DirName"
  done

  mqsilog "INFO:    Removing empty directories from the installation folder."

  for BaseDirName in $URemoveDirList
  do
    NextBaseDirName=$BaseDirName
    while [ ! -d "$BackupDirName/$NextBaseDirName" ]
    do
      if [ -d  "$InstallDir/$NextBaseDirName" ] ; then
        NumberOfFilesTotal=$(find "$InstallDir/$NextBaseDirName"  -type f -o -type l | wc -l)
        if [ $NumberOfFilesTotal -eq 0 ] ; then
          runcmd rm -rf "$InstallDir/$NextBaseDirName"
        else
          break
        fi
      fi
      NextBaseDirName=$(dirname "$NextBaseDirName")
    done

  done
  IFS=$CURRENT_IFS

  #########################################################################
  # If a directory is shipped with this fix, set the permissions
  # of restored new files.
  #########################################################################
  mqsilog ""
  mqsilog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Setting permissions of restored deleted files (if any)..."
  mqsilog "-------------------------------------------------------------------------------"

  IFS=$IFS_NEWLINE_SPLIT
  for Filename in $UNewFileList
  do
    mqsi_set_uninstall_permissions "$Filename"
  done

  for DirName in $UExistingOpaqueDirList
  do
    mqsi_set_uninstall_permissions "$DirName"
  done

  for Filename in $PermissionFileList
  do
    mqsi_set_uninstall_permissions "$Filename"
  done
  IFS=$CURRENT_IFS

  #########################################################################
  # Take ls -ilR listing for later reference.
  #########################################################################
  mqsilog "CMD:     ls -ilR $InstallDir > $UninstallBackupDirName/afterUninstall.log"
  if [ $dryrun -eq 0 ] ; then
    ls -ilR "$InstallDir" > "$UninstallBackupDirName/afterUninstall.log"
  fi


  #########################################################################
  # Remove the fix name (redirection operator means we cannot use runcmd).
  #########################################################################
  mqsilog ""
  mqsilog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Cleaning up..."
  mqsilog "-------------------------------------------------------------------------------"

  mqsilog "INFO:    Removing the fix name."
  mqsilog "CMD:     grep -v $FixName $InstallDir/mqsifixinst.dat > $InstallDir/mqsifixinst.tmp"
  mqsilog "CMD:     mv $InstallDir/mqsifixinst.tmp $InstallDir/mqsifixinst.dat"
  if [ $dryrun -eq 0 ] ; then
    grep -v "$FixName" "$InstallDir/mqsifixinst.dat" > "$InstallDir/mqsifixinst.tmp"
    mv "$InstallDir/mqsifixinst.tmp" "$InstallDir/mqsifixinst.dat"
    runcmd chmod 0664 "$InstallDir/mqsifixinst.dat"
  fi


  #########################################################################
  # Delete the backup directory for this fix.
  #########################################################################

  mqsilog "INFO:    Removing fix backup directory" $BackupDirName

  if [ "$OriginalDir" = "$BackupDirName" ] ; then
    runcmd cd "$BackupRootDirName"
    if [ $? -ne 0 ] ; then
      mqsiechonlog "FAILURE: Cannot change the directory to the root backup directory."
      exit 1
    fi
  fi
  runcmd rm -rf "$BackupDirName"
  if [ $? -ne 0 ] ; then
    mqsiechonlog "FAILURE: Cannot delete the fix backup directory" $BackupDirName
    exit 1
  fi

  if [ `ls "$BackupRootDirName" 2>/dev/null | wc -l` -eq 0 ] ; then

    mqsilog "INFO:    This fix is the only installed fix; therefore, removing the root backup directory" $BackupRootDirName

    if [ "$OriginalDir" = "$BackupDirName" ] ; then
      runcmd cd "$InstallDir"
      if [ $? -ne 0 ] ; then
        mqsiechonlog "FAILURE: Cannot change the directory to the installation directory."
        exit 1
      fi
    fi

    runcmd rm -rf "$BackupRootDirName"

    if [ $? -ne 0 ] ; then
      mqsiechonlog "FAILURE: Cannot delete the fix backup root directory" $BackupRootDirName
      exit 1
    fi

  fi

  #########################################################################
  # Delete the uninstallation backup directory for this fix.
  #########################################################################
  mqsilog "INFO:    Removing the uninstallation backup directory" $UninstallBackupDirName
  runcmd rm -rf "$UninstallBackupDirName"

  if [ $? -ne 0 ] ; then
    mqsiechonlog "FAILURE: Cannot delete the uninstallation backup directory" $UninstallBackupDirName
    exit 1
  fi

  if [ `ls "$UninstallRootBackupDir" 2>/dev/null | wc -l` -eq 0 ] ; then
    runcmd rm -rf "$UninstallRootBackupDir"
    if [ $? -ne 0 ] ; then
      mqsiechonlog "FAILURE: Cannot delete the uninstallation backup root directory" $UninstallRootBackupDir
    exit 1
    fi
  fi


  if [ $uninstall_all -eq 0 ] ; then
    #######################################################################
    # If we're not performing an uninstall_all then we need to perform post
    # uninstallation actions now. If we are performing an uninstall_all,
    # these actions can wait until the uninstall_all finishes.
    #######################################################################
    mqsi_post_install_uninstall_steps
  fi

}


####################################################################################
# FUNCTION mqsi_list_fixnames :
# Read mqsifixinst.dat and get all of the installed fixes.
####################################################################################
mqsi_list_installedfixes()
{
  mqsiechonlog "INFO:    Looking in $InstallDir/mqsifixinst.dat for installed fixes."

  if [ ! -f "$InstallDir/mqsifixinst.dat" ] ; then
    mqsilog "INFO:    No fixes are installed in installation $InstallDir."
    return 0
  fi

  Cmd="cat $InstallDir/mqsifixinst.dat | cut -d# -f1"
  mqsilog "CMD:     $Cmd"

  InstalledFixList=`cat "$InstallDir/mqsifixinst.dat" | cut -d# -f1`

  mqsilog "INFO:    Installed fixes : $InstalledFixList"

}


####################################################################################
# FUNCTION mqsi_search_fixname :
# Search for available fixes in the current directory that are ready to install.
####################################################################################
mqsi_search_fixname()
{

  Ncount=0
  if [ -d "$OriginalDir/readmes" ] ; then
    Cmd="find \"$OriginalDir/readmes\" -name \*.md5 -type f  -exec basename {} \;"
    mqsilog "CMD:     $Cmd"
    Available_FixNames=$(find "$OriginalDir/readmes" -name \*.md5 -type f  -exec basename {} \;)
    Ncount=$(echo $Available_FixNames | wc -w)
  fi

  if [ $Ncount -eq 0 ] ; then
    mqsiechonlog "INFO:    No fix is found in the current directory" $OriginalDir
    mqsiechonlog "INFO:    Run the script from the directory where you unpacked the fix."
    mqsiechonlog "FAILURE: Missing FixName parameter."
    exit 1
  fi


  if [ $Ncount -gt 1 ] ; then

    mqsiechonlog "INFO:    More than one fix is found in the current directory" $OriginalDir
    mqsiechonlog "INFO:    Please specify a FixName and rerun the script."
    mqsiechonlog "INFO:    Available fixes are:"
    for FixName in $Available_FixNames
    do
      mqsiechonlog "         Fix name: "${FixName%.md5}
    done
    mqsiechonlog "FAILURE: Missing FixName parameter."
    exit 1
  fi
 ####################################################################################
 # Set the only FixName that was found for the installation to continue
 ####################################################################################
  FixName=${Available_FixNames%.md5}
  CmdLineFixname=$FixName

  mqsiechonlog "INFO:    Found fix" $FixName
  mqsiechonlog ""

}


####################################################################################
# FUNCTION mqsi_set_mqsiversion : Read mqsi_version information from mqsiprofile
####################################################################################
mqsi_set_mqsiversion()
{

  MQSI_VERSION=$(grep 'MQSI_VERSION=' "$InstallDir/$MqsiprofileLoc" | cut -d= -f2)

  MQSIARCH=$(grep 'MQSI_PROCESSOR_ARCHITECTURE=' "$InstallDir/$MqsiprofileLoc" | cut -d= -f2)

  if [ -z "$MQSI_VERSION" ] ; then
    for line in $(< "$InstallDir/$MqsiprofileLoc")
    do
      case $line in
        MQSI_VERSION=*)  eval $line ;; # beware! eval!
        *) ;;
       esac
    done
  fi

  CurVersion=$MQSI_VERSION

}


####################################################################################
# FUNCTION mqsi_setup_basicvars : Setup the basic variables
####################################################################################
mqsi_setup_basicvars()
{

  #########################################################################
  # Set up the variables based on the action
  #########################################################################

  if [ "$ActionAsked" = "testinstall" ] ; then
    dryrun=1
    uninstall=0
  elif [ "$ActionAsked" = "testuninstall" ] ; then
    dryrun=1
    uninstall=1
  elif [ "$ActionAsked" = "install" ] ; then
    dryrun=0
    uninstall=0
  elif [ "$ActionAsked" = "uninstall" ] ; then
    dryrun=0
    uninstall=1
  elif [ "$ActionAsked" = "uninstall_no_mqsipatch_check" ] ; then
    dryrun=0
    uninstall=1
    avoid_mqsipatch_check=1
  elif [ "$ActionAsked" = "install_no_root" ] ; then
    dryrun=0
    uninstall=0
    avoid_root_check=1
  elif [ "$ActionAsked" = "uninstall_no_root" ] ; then
    dryrun=0
    uninstall=1
    avoid_root_check=1
  elif [ "$ActionAsked" = "uninstall_all_no_root" ] ; then
    dryrun=0
    uninstall=1
    uninstall_all=1
    avoid_root_check=1
  elif [ "$ActionAsked" = "install_avoid_ps_check" ] ; then
    dryrun=0
    uninstall=0
    avoid_ps_check=1
  elif [ "$ActionAsked" = "uninstall_avoid_ps_check" ] ; then
    dryrun=0
    uninstall=1
    avoid_ps_check=1
  elif [ "$ActionAsked" = "uninstall_all" ] ; then
    dryrun=0
    uninstall=1
    uninstall_all=1
  elif [ "$ActionAsked" = "uninstall_all_no_root" ] ; then
    dryrun=0
    uninstall=1
    uninstall_all=1
    avoid_root_check=1
  elif [ "$ActionAsked" = "install_no_toolkit_init" ] ; then
    dryrun=0
    uninstall=0
    avoid_toolkit_init=1
  elif [ "$ActionAsked" = "uninstall_no_toolkit_init" ] ; then
    dryrun=0
    uninstall=1
    avoid_toolkit_init=1
  elif [ "$ActionAsked" = "uninstall_all_no_toolkit_init" ] ; then
    dryrun=0
    uninstall=1
    uninstall_all=1
    avoid_toolkit_init=1
  elif [ "$ActionAsked" = "install_no_toolkit_init_no_root" ] ; then
    dryrun=0
    uninstall=0
    avoid_root_check=1
    avoid_toolkit_init=1
  elif [ "$ActionAsked" = "uninstall_no_toolkit_init_no_root" ] ; then
    dryrun=0
    uninstall=1
    avoid_root_check=1
    avoid_toolkit_init=1
  elif [ "$ActionAsked" = "uninstall_all_no_toolkit_init_no_root" ] ; then
    dryrun=0
    uninstall=1
    uninstall_all=1
    avoid_root_check=1
    avoid_toolkit_init=1
  else
    mqsiechonlog "FAILURE: Second argument must be a valid action."
    usage
    exit 1
  fi


  mqsi_set_mqsiversion

}


####################################################################################
# FUNCTION mqsi_setup_advancedvars : Setup the advanced variables
####################################################################################
mqsi_setup_advancedvars()
{

  #########################################################################
  # Set up some variables for use throughout this program.
  #########################################################################
  BackupRootDirName="$InstallDir/fix-backups.$CurVersion"

  # For install
  BackupDirName="$BackupRootDirName/$FixName"
  # For uninstall
  UninstallRootBackupDir="$InstallDir/fix-backups.$CurVersion.uninstall"
  UninstallBackupDirName="$InstallDir/fix-backups.$CurVersion.uninstall/$FixName"

  ReadmeDir="$OriginalDir/readmes"

  ReadmeFile="$OriginalDir/readmes/$FixName-README.txt"
  MqsifixinstDatFile="$OriginalDir/readmes/$FixName.dat"
  MqsifixinstMdFile="$OriginalDir/readmes/$FixName.md5"

  UDirList=''
  UDirNewFiles=''
  UExistingFileList=''
  UExistingOpaqueDirList=''
  UFileList=''
  UOpaqueDirList=''
  UNewFileList=''
  URemoveFileList=''
  URemoveOpaqueDirList=''
  USymLinkFileList=''
  USymLinkExistingList=''
  USymLinkRemoveList=''
  PermissionFileList=''

}


####################################################################################
# FUNCTION mqsi_root_check : Check if the script is running as root. If not, abort
####################################################################################
mqsi_root_check()
{

  #########################################################################
  # Verify that the user is root.  If this is a dry-run only, do not fail.
  # (If failing, we set the dryrun variable to allow mqsilog to work
  # without errors.)
  #########################################################################

  UserLoggedIn=$(whoami 2>/dev/null)
  if [ -z "$UserLoggedIn" ] ; then
    UserLoggedIn=$(/usr/ucb/whoami)
  fi

  if [ $dryrun -eq 0 ] && [ "$UserLoggedIn" != "root" ] ; then
    if [ $avoid_root_check -eq 0 ] ; then
      dryrun=1
      mqsiechonlog "FAILURE: "
      mqsiechonlog "        - You must be root to run in 'install' mode."
      mqsiechonlog "        - Non-root can run in 'test' mode."
      mqsiechonlog "        - Run with no arguments to see the usage statement."
      exit 1
    else
      mqsiechonlog "WARNING: avoid_root_check flag is used; continuing under a non-root user."
    fi
  fi


}


####################################################################################
# FUNCTION mqsi_installdir_check : Check if the installation directory is valid
####################################################################################
mqsi_installdir_check()
{

  Ncount=$(echo  $InstallDir | wc -w)

  # if [ $Ncount -gt 1 ] ; then
  #   mqsiechonlog "FAILURE: Installation directory path contains white space, which is not supported by the script."
  #   mqsiechonlog "         Installation can be performed manually by following the steps given in the fix readme file."
  #   exit 1
  # fi

  if [ ! -f "$InstallDir/bin/mqsiprofile" ] ; then

    if [ ! -f "$InstallDir/server/bin/mqsiprofile" ] ; then
      mqsiechonlog "FAILURE: $InstallDir is not a valid "
      mqsiechonlog "         IBM Integration Bus or IBM App Connect Enterprise installation directory."
      exit 1
    else
      MqsiprofileLoc="server/bin/mqsiprofile"
      MqsiTenFix=1
    fi

  fi

}


####################################################################################
# FUNCTION mqsi_install_prereq : Check various aspects before installation
####################################################################################
mqsi_install_prereq()
{

  #########################################################################
  # Verify that we are in the correct directory
  #########################################################################

    if [ ! -f "$ReadmeFile" ] ; then
      mqsiechonlog "FAILURE: $ReadmeFile file is not present."
      mqsiechonlog "         Change to the directory that contains unpacked fix files"
      mqsiechonlog "         or ensure that the FixName : $CmdLineFixname is correct."
      exit 1
    fi

    if [ ! -f "$MqsifixinstDatFile" ] ; then
      mqsiechonlog "FAILURE: $MqsifixinstDatFile file is not present."
      mqsiechonlog "         Change to the directory that contains unpacked fix files"
      mqsiechonlog "         or ensure that the FixName : $CmdLineFixname is correct."
      exit 1
    fi

    if [ ! -f "$MqsifixinstMdFile" ] ; then
      mqsiechonlog "FAILURE: $MqsifixinstMdFile file is not present."
      mqsiechonlog "         Change to the directory that contains unpacked fix files"
      mqsiechonlog "         or make sure that the FixName : $CmdLineFixname is correct."
      exit 1
    fi

    mqsilog "INFO:    Extracting fix information from $MqsifixinstDatFile"
    #######################################################################
    # Extract the patch information from the README.txt file.
    #######################################################################
    IFS="- " read tag1 tag2 PatchVersion tag3 tag4 PLATFORM tag5 < "$MqsifixinstDatFile"
    if [ "$tag3" = "IIB" ] || [ "$tag3" = "ACE" ] ; then
      IFS="- " read tag1 tag2 PatchVersion tag3 PLATFORM tag5 < "$MqsifixinstDatFile"
    fi
    IFS=" " read tag1 tag2 FixName < "$MqsifixinstDatFile"

    #######################################################################
    # More commentary
    #######################################################################
    mqsilog "INFO:    Fix name is $FixName"
    mqsilog "INFO:    The fix is intended for version $PatchVersion"
    mqsilog "INFO:    The fix is intended for $PLATFORM"

    mqsiechonlog "INFO:    FixName           :" $FixName
    mqsiechonlog "INFO:    Fix Source        :" $OriginalDir
    mqsiechonlog "INFO:    Action            :" $ActionAsked
    mqsiechonlog "INFO:    Install Directory :" $InstallDir
    mqsiechonlog "INFO:    Install VRMF      :" $CurVersion
    mqsiechonlog "INFO:    OS                :" $(uname)


    if [ -z "$FixName" ] || [ -z "$PatchVersion" ] || [ -z "$PLATFORM" ] ; then
      mqsiechonlog "FAILURE: Cannot parse for FixName, FixVersion, or Platform."
      exit 1
    fi


    if [ "$CmdLineFixname" != "$FixName" ] ; then
      mqsiechonlog "FAILURE: Fix name validity check failed."
      mqsiechonlog "         Ensure that the FixName : $CmdLineFixname is correct."
      exit 1
    fi



  #########################################################################
  # Check that the current MQSI version matches the fix version.
  #########################################################################
  mqsilog "INFO:    Checking that the installed version and the fix version are the same."

  if [ "$CurVersion" != "$PatchVersion" ] ; then

    PatchVersion_V=`echo $PatchVersion | awk -F'.' '{print $1}'`
    PatchVersion_R=`echo $PatchVersion | awk -F'.' '{print $2}'`
    PatchVersion_M=`echo $PatchVersion | awk -F'.' '{print $3}'`
    PatchVersion_F=`echo $PatchVersion | awk -F'.' '{print $4}'`

    if [ "$PatchVersion_F" = "x" ] || [ "$PatchVersion_F" = "X" ] ; then
      mqsiechonlog "INFO:    Fix is applicable to all fixpacks of version $PatchVersion_V.$PatchVersion_R."
      CurVersion_V=`echo $CurVersion | awk -F'.' '{print $1}'`
      CurVersion_R=`echo $CurVersion | awk -F'.' '{print $2}'`

      if [ "$PatchVersion_V" = "$CurVersion_V" ] && [ "$PatchVersion_R" = "$CurVersion_R" ] ; then
        DotXFixName=1
        mqsilog "INFO:    Installed version $CurVersion_V.$CurVersion_R matches intended version."
      else
        mqsiechonlog "FAILURE: Current installation version($CurVersion_V.$CurVersion_R) does not match fix version($PatchVersion_V.$PatchVersion_R)"
        mqsiechonlog "         The profile inside the installation directory states that the version is $CurVersion_V.$CurVersion_R"
        mqsiechonlog "         However, the fix is intended for $PatchVersion_V.$PatchVersion_R."
        mqsiechonlog "         Therefore, this fix cannot be installed in the directory $InstallDir at this time."
        exit 1
     fi

    else

      mqsiechonlog "FAILURE: Current installation version($CurVersion) does not match fix version($PatchVersion)"
      mqsiechonlog "         The profile inside the installation directory states that the version is $CurVersion"
      mqsiechonlog "         However, the fix is intended for $PatchVersion."
      mqsiechonlog "         Therefore, this fix cannot be installed in the directory $InstallDir at this time."
      exit 1

   fi
  else
    mqsilog "INFO:    Installed version $CurVersion at $InstallDir matches intended version."
  fi


  #########################################################################
  # Check mqsifixinst.dat for evidence that the fix is already installed.
  #
  # For installation:
  # If the fix is already installed, write failure and exit with 0.
  #########################################################################

  if [ -f "$InstallDir/mqsifixinst.dat" ] ; then

    mqsilog "INFO:    Checking $InstallDir/mqsifixinst.dat for evidence of $FixName"

    if [ $DotXFixName -eq 1 ] ; then
      GrepOutput=`grep "$FixName($CurVersion)" "$InstallDir/mqsifixinst.dat" | wc -l`
    else
      GrepOutput=`grep "$FixName" "$InstallDir/mqsifixinst.dat" | wc -l`
    fi

    rc=$?
    if [ $rc -ne 0 ] ; then
      mqsiechonlog "FAILURE: Cannot process the file $InstallDir/mqsifixinst.dat"
      exit 1
    fi

    if [ $GrepOutput = 0 ] ; then
      mqsilog "INFO:    The fix has not been installed before; continuing."
    elif [ $GrepOutput = 1 ] ; then
      mqsiechonlog "FAILURE: The fix is already installed."
      exit 1
    else
      mqsiechonlog "FAILURE: $InstallDir/mqsifixinst.dat contains $GrepOutput entries"
      mqsiechonlog "         for fix $FixName. 0 or 1 entries should be present."
      mqsiechonlog "         Investigate whether the fix is installed or if a previous"
      mqsiechonlog "         uninstallation or installation has failed."
      exit 1
    fi
  fi


}


####################################################################################
# FUNCTION mqsi_uninstall_prereq :
# Check various aspects before uninstallation
####################################################################################
mqsi_uninstall_prereq()
{

  #########################################################################
  # Check mqsifixinst.dat for evidence that the fix is already installed.
  # For uninstallation:
  # If the fix is not already installed, write a warning and exit with 0.
  #########################################################################
  if [ -f $InstallDir/mqsifixinst.dat ] ; then
    mqsilog "INFO:    Checking $InstallDir/mqsifixinst.dat for evidence of $FixName"
    GrepOutput=`grep "$FixName" "$InstallDir/mqsifixinst.dat" | wc -l`
    rc=$?
    if [ $rc -ne 0 ] ; then
      mqsiechonlog "FAILURE: Cannot process the file $InstallDir/mqsifixinst.dat"
      exit 1
    fi

    if [ $GrepOutput = 0 ] ; then
      if [ $avoid_mqsipatch_check -eq 0 ] ; then
        mqsiechonlog "WARNING: $InstallDir/mqsifixinst.dat does not mention this fix."
        mqsiechonlog "         Investigate whether the fix was installed."
        mqsiechonlog "         (The updates to the mqsifixinst.dat file might have failed)."
        mqsiechonlog "         You can bypass this check on the mqsifixinst.dat file "
        mqsiechonlog "         by using the uninstall_no_mqsipatch_check action."
        mqsiechonlog "         Exiting with rc=0."
        exit 0
      else
        mqsiechonlog "WARNING: $InstallDir/mqsifixinst.dat does not mention this fix;"
        mqsiechonlog "         continuing."
      fi
    elif [ $GrepOutput = 1 ] ; then
      mqsilog "INFO:    The fix is already installed; continuing."
    else
      mqsiechonlog "FAILURE: $InstallDir/mqsifixinst.dat contains $GrepOutput entries"
      mqsiechonlog "         for fix $FixName. 0 or 1 entries should be present."
      mqsiechonlog "         Investigate whether the fix is installed or if a previous"
      mqsiechonlog "         uninstallation or installation has failed."
      exit 1
    fi
  fi

  #######################################################################
  # Extract the patch information from the fixname
  #######################################################################
  mqsilog "INFO:    Extracting fix informaton from $FixName"
  PROD=`IFS="-"; echo ${FixName} | awk '{print $2}'`
  if [ "$PROD" = "IIB" ] || [ "$PROD" = "ACE" ] ; then
    PLATFORM=`IFS="-"; echo ${FixName} | awk '{print $3}'`
  else
    PLATFORM=`IFS="-"; echo ${FixName} | awk '{print $4}'`
  fi

  mqsilog "INFO:    The fix platform is $PLATFORM"

  mqsiechonlog "INFO:    FixName           :" $FixName
  mqsiechonlog "INFO:    Current Directory :" $OriginalDir
  mqsiechonlog "INFO:    Action            :" $ActionAsked
  mqsiechonlog "INFO:    Install Directory :" $InstallDir
  mqsiechonlog "INFO:    Install VRMF      :" $CurVersion
  mqsiechonlog "INFO:    OS                :" $(uname)

}


####################################################################################
# FUNCTION mqsiplatform_check :
# Checks if the fix is intended for the current platform
####################################################################################
mqsi_platform_check()
{

  if [ "$PLATFORM" = "LinuxIA32" ] ; then
    if [ "$(uname)" != "Linux" ] || [ "$(uname -m)" != "i686" ] ; then

      if [ "$MQSIARCH" != "32" ] ; then
        mqsiechonlog "FAILURE: Expecting Linux 32 bit installation."
        exit 1
      fi

    fi
  elif [ "$PLATFORM" = "LinuxX64" ] ; then
    if [ "$(uname)" != "Linux" ] || [ "$(uname -m)" != "x86_64" ] || [ "$MQSIARCH" != "64" ] ; then
      mqsiechonlog "FAILURE: Expecting Linux X86_64 bit installation. "
      exit 1
    fi
  elif [ "$PLATFORM" = "LinuxPPC64" ] ; then
    if [ "$(uname)" != "Linux" ] || [ "$(uname -m)" != "ppc64" ] ; then
      mqsiechonlog "FAILURE: Expecting Linux ppc64 installation."
      exit 1
    fi
  elif [ "$PLATFORM" = "LinuxPPCLE64" ] ; then	
    if [ "$(uname)" != "Linux" ] || [ "$(uname -m)" != "ppc64le" ] ; then
      mqsiechonlog "FAILURE: Expecting Linux ppc64le installation."
      exit 1
    fi
  elif [ "$PLATFORM" = "Linuxz64" ] ; then
    if [ "$(uname)" != "Linux" ] || [ "$(uname -m)" != "s390x" ] ; then
      mqsiechonlog "FAILURE: Expecting Linux s390x installation."
      exit 1
    fi
  elif [ "$PLATFORM" = "Linuxz31" ] ; then
    if [ "$(uname)" != "Linux" ] || [ "$(uname -m)" != "s390" ] ; then
      mqsiechonlog "FAILURE: Expecting Linux s390 installation."
      exit 1
    fi
  elif [ "$PLATFORM" = "AIXPPC64" ] ; then
    if [ "$(uname)" != "AIX" ] || [ "$(uname -p)" != "powerpc" ] ; then
      mqsiechonlog "FAILURE: Expecting AIX powerpc installation."
      exit 1
    fi
  elif [ "$PLATFORM" = "SolarisSparc64" ] ; then
    if [ "$(uname)" != "SunOS" ] || [ "$(uname -p)" != "sparc" ] ; then
      mqsiechonlog "FAILURE: Expecting SunOS sparc installation."
      exit 1
    fi
  elif [ "$PLATFORM" = "SolarisX64" ] ; then
    if [ "$(uname)" != "SunOS" ] || [ "$(uname -p)" != "i386" ] ; then
      mqsiechonlog "FAILURE: Expecting SunOS i386 installation."
      exit 1
    fi
  elif [ "$PLATFORM" = "HPUXPARISC64" ] ; then
    if [ "$(uname)" != "HP-UX" ] || [ "$(uname -m)" != "9000/800" ] ; then
      mqsiechonlog "FAILURE: Expecting HP-UX 9000/800 installation."
      exit 1
    fi
  elif [ "$PLATFORM" = "HPUXIA64" ] ; then
    if [ "$(uname)" != "HP-UX" ] || [ "$(uname -m)" != "ia64" ] ; then
      mqsiechonlog "FAILURE: Expecting HP-UX ia64 installation."
      exit 1
    fi
  elif [ "$PLATFORM" = "MacOSX64" ] ; then
    if [ "$(uname)" != "Darwin" ] || [ "$(uname -m)" != "x86_64" ] ; then
      mqsiechonlog "FAILURE: Expecting macOS x86_64 installation."
      exit 1
    fi
  else
    mqsiechonlog "FAILURE: Unexpected OS and hardware string $PLATFORM"
    exit 1
  fi

  mqsilog "INFO:    Installation OS and hardware type checked OK"

}


####################################################################################
# FUNCTION mqsi_process_check :
# Checks if any broker process is using the installation directory
####################################################################################
mqsi_process_check()
{

  InstallDirSlashd=$InstallDir/
  mqsilog "INFO:    Checking if any brokers or integration nodes are using this installation."
  mqsilog "CMD:     ps -ef | grep DataFlowEngine | grep $InstallDirSlashd | wc -l"

  if [ `ps -ef | grep DataFlowEngine | grep "$InstallDirSlashd" | wc -l ` -gt 0 ] ; then
    mqsiechonlog "FAILURE: Installation directory $InstallDirSlashd has broker or integration node processes running."
    mqsiechonlog "         Use the mqsistop command to stop all brokers or integration nodes and rerun the script."
    exit 1
  else
    if [ "$(uname)" = "AIX" ] ; then
      mqsilog "CMD:     ps acex| grep -F -e bipbroker -e bipservice -e DataFlowEngine -e biphttplistener -e bipMQTT | grep $InstallDirSlashd | wc -l"
      NumbrOfBrokers=$(ps acex| grep -F -e bipbroker -e bipservice -e DataFlowEngine -e biphttplistener -e bipMQTT | grep "$InstallDirSlashd" | wc -l)
      if [ $NumbrOfBrokers -gt 0 ] ;then
        mqsiechonlog "FAILURE: Installation directory $InstallDirSlashd has broker or integration node processes running."
        mqsiechonlog "         Use the mqsistop command to stop all brokers or integration nodes and rerun the script."
        exit 1
      else
        mqsilog "INFO:    Brokers or integration nodes for installation directory $InstallDirSlashd are not running."
        mqsilog "INFO:    Continuing the action:  $ActionAsked."
      fi

    elif [ "$(uname)" = "Linux" ] ; then
      mqsilog "CMD:     pgrep 'bipservice|bipbroker|DataFlowEngine|biphttplistener|bipMQTT"
      LstOfBrk=$(pgrep 'bipservice|bipbroker|DataFlowEngine|biphttplistener|bipMQTT')
      for BPid in $LstOfBrk
      do
        UCount=$(ls -ald /proc/$BPid/exe 2>/dev/null | grep "$InstallDirSlashd" | wc -l)
        if [ $UCount -gt 0 ] ; then
          mqsiechonlog "FAILURE: Installation directory $InstallDirSlashd has broker or integration node processes running."
          mqsiechonlog "         One such process pid is $BPid."
          mqsiechonlog "         Use the mqsistop command to stop all brokers and integration nodes and rerun the script."
          exit 1
        fi
      done

      mqsilog "INFO:    Brokers or integration nodes for installation directory $InstallDirSlashd are not running."

      if [ "$PLATFORM" = "LinuxX64" ] && [ $MqsiTenFix -eq 1 ] ; then
        mqsilog "INFO:    Checking if IBM Integration Toolkit is in use."
        LstOfToolkit=$(pgrep 'eclipse')
        for BPid in $LstOfToolkit
        do
          UCount=$(ls -ald /proc/$BPid/exe 2>/dev/null | grep "$InstallDirSlashd" | wc -l)
          if [ $UCount -gt 0 ] ; then
            mqsiechonlog "FAILURE: Stop the IBM Integration Toolkit for the installation and try again."
            exit 1
          fi
        done
        mqsilog "INFO:    IBM Integration Toolkit is not in use."
      fi
      mqsilog "INFO:    Continuing the action: $ActionAsked."
    elif [ "$(uname)" = "SunOS" ] ; then
      mqsilog "CMD:     pgrep 'bipservice|bipbroker|DataFlowEngine|biphttplistener|bipMQTT"
      LstOfBrk=$(pgrep 'bipservice|bipbroker|DataFlowEngine|biphttplistener|bipMQTT')
      for BPid in $LstOfBrk
      do
        UCount=$(ls -ald /proc/$BPid/path/a.out 2>/dev/null | grep "$InstallDirSlashd" | wc -l)
        if [ $UCount -gt 0 ] ; then
          mqsiechonlog "FAILURE: Installation directory $InstallDirSlashd has broker or integration node processes running."
          mqsiechonlog "         One such process pid is $BPid."
          mqsiechonlog "         Use the mqsistop command to stop all brokers or integration nodes and rerun the script."
          exit 1
        fi
      done
      mqsilog "INFO:    Brokers or integration nodes for installation directory $InstallDirSlashd are not running."
      mqsilog "INFO:    Continuing the action: $ActionAsked."
    elif [ "$(uname)" = "HP-UX" ] ; then
      if [ $avoid_ps_check -eq 0 ] ; then
        mqsiechonlog "INFO:    On HP-UX, you must stop all brokers for installation to continue."
        mqsilog "CMD:     ps -ef | grep -F -e bipbroker -e bipservice -e DataFlowEngine -e biphttplistener -e bipMQTT | grep -v -e grep |wc -l"
        RnBrkCnt=$(ps -ef | grep -F -e bipbroker -e bipservice -e DataFlowEngine -e biphttplistener -e bipMQTT | grep -v -e grep |wc -l)
        if [ RnBrkCnt -eq 0 ] ; then
          mqsilog "INFO:    Brokers or integration nodes are not active on this machine."
          mqsilog "INFO:    Continuing the action: $ActionAsked."
        else
          mqsiechonlog "FAILURE: Found $RnBrkCnt broker or integration node processes running on this machine."
          mqsiechonlog "         Stop all the brokers and integration nodes and rerun the script."
          mqsiechonlog "         You can bypass this check for all the running brokers on HP-UX "
          mqsiechonlog "         by using ACTION install_avoid_ps_check or uninstall_avoid_ps_check. "
          exit 1
        fi
      else
        mqsiechonlog "INFO:    avoid_ps_check flag is used; therefore, continuing installation without further checks."
      fi
    fi
  fi

}


####################################################################################
# FUNCTION mqsi_uninstall_all : Uninstall every fix
####################################################################################
mqsi_uninstall_all()
{
  # This line is deliberately mqsilog to only log in verbose mode
  mqsilog ""

  mqsiechonlog "-------------------------------------------------------------------------------"
  mqsiechonlog ""
  mqsiechonlog "INFO:    Uninstalling all fixes."

  if [ ! -f "$InstallDir/mqsifixinst.dat" ] ; then

    mqsiechonlog "INFO:    No fixes are found to uninstall."

  else

    mqsi_list_installedfixes

    InFixcount=$(echo $InstalledFixList | wc -w)

    if [ $InFixcount -eq 0 ] ; then
      mqsiechonlog "INFO:    No fixes are found to uninstall."
    fi

    mqsiechonlog "INFO:    Found the following fix(s):"
    for FixNameTemp in $InstalledFixList
    do
      FixNameTemp2=${FixNameTemp%"($CurVersion)"}
      mqsiechonlog "INFO:    Fix: $FixNameTemp2"
    done

    for FixNameTemp in $InstalledFixList
    do
      FixName=${FixNameTemp%"($CurVersion)"}
      mqsi_setup_advancedvars

      mqsiechonlog ""
      mqsiechonlog "-------------------------------------------------------------------------------"
      mqsiechonlog "INFO:    About to uninstall fix $FixName."
      mqsiechonlog "-------------------------------------------------------------------------------"

      #######################################################################
      # Extract the patch information from the fixname. We need this later
      # to check the PLATFORM for toolkit re-initialization
      #######################################################################
      mqsilog "INFO:    Extracting fix informaton from $FixName"
      PROD=`IFS="-"; echo ${FixName} | awk '{print $2}'`
      if [ "$PROD" = "IIB" ] || [ "$PROD" = "ACE" ] ; then
        PLATFORM=`IFS="-"; echo ${FixName} | awk '{print $3}'`
      else
        PLATFORM=`IFS="-"; echo ${FixName} | awk '{print $4}'`
      fi

      mqsilog "INFO:    The fix platform is $PLATFORM"

      do_uninstall

      mqsiechonlog ""
      mqsiechonlog "-------------------------------------------------------------------------------"
      mqsiechonlog "INFO:    Successfully uninstalled $FixName."
      UninstallAllCount=$(($UninstallAllCount+1))
    done

    #######################################################################
    # Perform post uninstall actions now.
    #######################################################################
    mqsi_post_install_uninstall_steps

  fi

}


####################################################################################
####################################################################################
#
# PROGRAM BEGINS HERE
#
####################################################################################
####################################################################################

OriginalDir=`pwd`
Date=$(date +\%Y\%m\%d-\%H\%M\%S)
ThisScriptName=$0
InputArgs=$@

mqsiecho "-------------------------------------------------------------------------------"
mqsiecho "      IBM Integration Bus and IBM App Connect Enterprise Fix Installer v$MQSIF_SCRIPTVERSION"
mqsiecho "-------------------------------------------------------------------------------"
mqsiecho ""
mqsiecho "INFO:    Date:   " $(date +\%Y/\%m/\%d)
mqsiecho "INFO:    Time:   " $(date +\%H:\%M:\%S)
mqsiecho ""

###########################################################################
# Initialize the variables
###########################################################################


if [ $# -ne 3 ] ; then

  if [ $# -eq 4 ] ; then
    if [ "$4" = "verbose" ] ; then
      Verbose_Mqsi=1
    else
      mqsiechonlog "FAILURE: Incorrect number of parameters."
      usage
      exit 1
    fi
  elif [ $# -eq 2 ] ; then
    Find_Fixname=1
  else
    mqsiechonlog "FAILURE: Incorrect number of parameters."
    usage
    exit 1
  fi

fi

if [ ! -d "$1" ] ; then
  mqsiechonlog "FAILURE: Invalid installation directory parameter $1"
  usage
  exit 1
fi

if [ $Find_Fixname -eq 0 ] ; then
  if [ "$3" = "verbose" ] ; then
    Find_Fixname=1
    Verbose_Mqsi=1
  else
    CmdLineFixname=$3
    FixName=$3
  fi
fi

ThisScript="$OriginalDir/$(basename "$0")"
ReadmeFile="$OriginalDir/readmes/$CmdLineFixname-README.txt"
MqsifixinstDatFile="$OriginalDir/readmes/$CmdLineFixname.dat"
MqsifixinstMdFile="$OriginalDir/readmes/$CmdLineFixname.md5"

####################################################################################
# Drop any trailing slash from the InstallDir (first argument).
####################################################################################
InstallDirTemp="$(dirname "$1")/$(basename "$1")"

if [ -h "$InstallDirTemp" ] ; then
  InstallDirTemp=$(ls -l "$InstallDirTemp" | awk '{print $NF}')
fi

InstallDir=$(cd "$InstallDirTemp";pwd)

ActionAsked=$2


####################################################################################
# Call the intial functions
####################################################################################
mqsi_installdir_check
mqsi_setup_basicvars

CurVersion_V=`echo $CurVersion | awk -F'.' '{print $1}'`

if [ $CurVersion_V -ge 10 ]  &&  [ $MqsiTenFix -eq 0 ] ; then
  mqsiechonlog "FAILURE: $InstallDir is not a valid "
  mqsiechonlog "         IBM Integration Bus installation directory."
  mqsiechonlog "         Did you mean $(dirname "$InstallDir")?"
  exit 1
fi

mqsi_root_check


####################################################################################
# Start logging in the mqsifixinst.log file
####################################################################################
TMP_Verbose_Mqsi=$Verbose_Mqsi
Verbose_Mqsi=0

if [ $dryrun -eq 0 ] && [ -d "$InstallDir" ] ; then
  Enable_Logfile=1
  mqsilog "-------------------------------------------------------------------------------"
  mqsilog "      IBM Integration Bus and IBM App Connect Enterprise Fix Installer v$MQSIF_SCRIPTVERSION"
  mqsilog "-------------------------------------------------------------------------------"
  mqsilog ""
  mqsilog "INFO:    Date:   " $(date +\%Y/\%m/\%d)
  mqsilog "INFO:    Time:   " $(date +\%H:\%M:\%S)
  mqsilog ""
fi

Verbose_Mqsi=$TMP_Verbose_Mqsi


if [ $uninstall_all -eq 0 ] && [ $uninstall -eq 1 ] && [ $Find_Fixname -eq 1 ] ; then

  mqsiechonlog "-------------------------------------------------------------------------------"
  mqsiechonlog ""

  if [ "$OriginalDir" != "$InstallDir" ] ; then

    Ncount=0
    if [ -d "$OriginalDir/readmes" ] ; then
      mqsiechonlog "INFO:    No fix name supplied. Checking readmes directory."
      Cmd="find $OriginalDir/readmes -name \*.md5 -type f  -exec basename {} \;"
      mqsilog "CMD:     $Cmd"
      Available_FixNames=$(find "$OriginalDir/readmes" -name \*.md5 -type f  -exec basename {} \;)
      Ncount=$(echo  $Available_FixNames | wc -w)

      if [ $Ncount -eq 0 ] ; then
        mqsiechonlog "INFO:    No fix found in the readmes directory " $OriginalDir
      fi
    fi

    if [ $Ncount -eq 1 ] ; then
      FixName=${Available_FixNames%.md5}
      CmdLineFixname=$FixName
      mqsiechonlog "INFO:    Found fix $FixName. Will attempt to uninstall this fix."

      GrepOutput=0
      if [ -f "$InstallDir/mqsifixinst.dat" ] ; then
        mqsilog "INFO:    Checking $InstallDir/mqsifixinst.dat for evidence of $FixName"
        GrepOutput=`grep "$FixName" "$InstallDir/mqsifixinst.dat" | wc -l`
        rc=$?
        if [ $rc -ne 0 ] ; then
          mqsiechonlog "FAILURE: Cannot process the file $InstallDir/mqsifixinst.dat"
          exit 1
        fi
      fi

      if [ $GrepOutput = 0 ] ; then
        mqsiechonlog "FAILURE: The fix $FixName is not installed. "
        exit 1
      else
        mqsiechonlog ""
        mqsiechonlog "-------------------------------------------------------------------------------"
        mqsiechonlog "INFO:    Validating the environment"
        mqsiechonlog "-------------------------------------------------------------------------------"

        mqsi_uninstall_prereq
        mqsi_process_check
        mqsi_setup_advancedvars
        do_uninstall
        mqsiechonlog ""
        mqsiechonlog "-------------------------------------------------------------------------------"
        mqsiechonlog "INFO:    Result Summary"
        mqsiechonlog "-------------------------------------------------------------------------------"
        if [ $dryrun -eq 1 ] ; then
          mqsiechonlog "INFO:    The test uninstallation completed successfully. To uninstall the fix,"
          mqsiechonlog "         rerun this script with the uninstall option under the root user."
        else
          mqsiechonlog "INFO:    Successfully uninstalled" $FixName
          mqsiechonlog "INFO:    Remember to restart brokers or integration nodes that "
          mqsiechonlog "         were stopped to perform this fix uninstallation."
        fi
        mqsiechonlog ""
        mqsiechonlog "-------------------------------------------------------------------------------"
        exit 0
      fi
    fi

    if [ $Ncount -gt 1 ] ; then
      mqsiechonlog "INFO:    More than one fix is found in the current directory."
      mqsiechonlog "INFO:    Please specify a FixName and rerun the script."
      mqsiechonlog "INFO:    Available fixes are:"

      for Available_FixName in $Available_FixNames
      do
        Available_FixName=${Available_FixName%.md5}
        mqsiechonlog "         Fix name: "$Available_FixName
      done
      mqsiechonlog "FAILURE: Missing FixName parameter."
      exit 1
    fi

  fi

  mqsiechonlog "INFO:    No fix name supplied. Checking installation directory."

  mqsi_list_installedfixes

  InFixcount=$(echo $InstalledFixList | wc -w)

  if [ $InFixcount -eq 0 ] ; then

    mqsiechonlog "INFO:    No installed fixes found in $InstallDir."

  else

    mqsiechonlog "INFO:    Found the following fixes installed: "
    for FixName in $InstalledFixList
    do
      mqsiechonlog "         Fix name: "$FixName
    done

  fi

  mqsiechonlog "FAILURE: Missing FixName parameter."
  mqsiechonlog "         The uninstall action cannot continue without specifying a fix name."
  mqsiechonlog "         Specify the fix name to be uninstalled and rerun the script;"
  mqsiechonlog "         Alternatively use the uninstall_all action."
  exit 1
fi


if [ $uninstall_all -eq 1 ] ; then

  mqsilog "-------------------------------------------------------------------------------"
  mqsilog "INFO:    Validating the environment"
  mqsilog "-------------------------------------------------------------------------------"

  mqsi_process_check
  mqsi_uninstall_all

  mqsiechonlog ""
  mqsiechonlog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Result Summary"
  mqsiechonlog "-------------------------------------------------------------------------------"
  mqsiechonlog "INFO:    Successfully uninstalled $UninstallAllCount fixes."
  mqsiechonlog "INFO:    Remember to restart brokers or integration nodes that were stopped to"
  mqsiechonlog "         perform this fix uninstallation."
  mqsiechonlog ""
  mqsiechonlog "-------------------------------------------------------------------------------"
  mqsiechonlog " "
  exit 0
fi


if [ $uninstall -eq 0 ] && [ $Find_Fixname -eq 1 ] ; then

  mqsiechonlog "-------------------------------------------------------------------------------"
  mqsiechonlog

  mqsiechonlog "INFO:    No fix name supplied. Checking readmes directory."
  mqsilog "INFO:    Searching for available FixName(s) present in current directory " $OriginalDir
  mqsi_search_fixname
fi

mqsiechonlog "-------------------------------------------------------------------------------"
mqsiechonlog "INFO:    Validating the environment"
mqsiechonlog "-------------------------------------------------------------------------------"

mqsi_setup_advancedvars

###########################################################################
# Tell the user what type of activity this script will attempt
###########################################################################
if [ $dryrun -eq 1 ] ; then
  mqsiechonlog "INFO:    This run will be a test-only run."
fi

###########################################################################
# Perform detailed checks
###########################################################################

if [ $uninstall -eq 0 ] ; then
  mqsi_install_prereq
  mqsi_platform_check
else
  mqsi_uninstall_prereq
fi
mqsi_process_check


###########################################################################
# BRANCH: install or uninstall
###########################################################################
if [ $uninstall -eq 0 ] ; then
  do_install
else
  do_uninstall
fi

###########################################################################
# Done
###########################################################################
mqsiechonlog ""
mqsiechonlog "-------------------------------------------------------------------------------"
mqsiechonlog "INFO:    Result Summary"
mqsiechonlog "-------------------------------------------------------------------------------"
if [ $dryrun -eq 1 ] ; then
  if [ $uninstall -eq 0 ] ; then
    mqsiechonlog "INFO:    The test installation completed successfully. To install the fix,"
    mqsiechonlog "         rerun this script with the install option under the root user."
  else
    mqsiechonlog "INFO:    The test uninstallation completed successfully. To uninstall the fix,"
    mqsiechonlog "         rerun this script with the uninstall option under the root user."
  fi
else
  if [ $uninstall -eq 0 ] ; then
    mqsiechonlog "INFO:    Successfully installed" $FixName
    mqsiechonlog "INFO:    Remember to restart brokers or integration nodes that were stopped"
    mqsiechonlog "         to perform this fix installation."
  else
    mqsiechonlog "INFO:    Successfully uninstalled" $FixName
    mqsiechonlog "INFO:    Remember to restart brokers or integration nodes that were stopped"
    mqsiechonlog "         to perform this fix uninstallation."
  fi
fi
mqsiechonlog ""
mqsiechonlog "-------------------------------------------------------------------------------"
mqsiechonlog " "

exit 0
